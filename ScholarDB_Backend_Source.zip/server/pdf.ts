import PDFDocument from 'pdfkit';
import { getAnalytics, getSchemaMetadata } from './db.ts';

function ensureSpace(doc: PDFKit.PDFDocument, neededHeight: number): void {
  const bottomLimit = doc.page.height - doc.page.margins.bottom;
  if (doc.y + neededHeight > bottomLimit) {
    doc.addPage();
  }
}

function drawSectionHeading(doc: PDFKit.PDFDocument, title: string, subtitle?: string): void {
  ensureSpace(doc, 52);
  doc.moveDown(0.5);
  doc
    .font('Helvetica-Bold')
    .fontSize(13)
    .fillColor('#0f172a')
    .text(title);
  if (subtitle) {
    doc
      .font('Helvetica')
      .fontSize(9)
      .fillColor('#475569')
      .text(subtitle);
  }
  const lineY = doc.y + 4;
  doc
    .moveTo(doc.page.margins.left, lineY)
    .lineTo(doc.page.width - doc.page.margins.right, lineY)
    .lineWidth(0.75)
    .strokeColor('#cbd5e1')
    .stroke();
  doc.y = lineY + 8;
}

function drawTable(
  doc: PDFKit.PDFDocument,
  headers: string[],
  rows: string[][],
  colWidths: number[],
  alignments?: Array<'left' | 'right'>
): void {
  const startX = doc.page.margins.left;
  const rowHeight = 18;

  const drawHeaderRow = () => {
    ensureSpace(doc, rowHeight * 2);
    const y = doc.y;
    doc
      .rect(startX, y, colWidths.reduce((a, b) => a + b, 0), rowHeight)
      .fill('#f1f5f9');

    let x = startX;
    headers.forEach((h, idx) => {
      doc
        .font('Helvetica-Bold')
        .fontSize(8)
        .fillColor('#334155')
        .text(h, x + 5, y + 5, {
          width: colWidths[idx] - 10,
          align: alignments?.[idx] ?? 'left',
          lineBreak: false,
          ellipsis: true,
        });
      x += colWidths[idx];
    });
    doc.y = y + rowHeight;
  };

  drawHeaderRow();

  rows.forEach((row, rIdx) => {
    if (doc.y + rowHeight > doc.page.height - doc.page.margins.bottom) {
      doc.addPage();
      drawHeaderRow();
    }
    const y = doc.y;
    if (rIdx % 2 === 1) {
      doc
        .rect(startX, y, colWidths.reduce((a, b) => a + b, 0), rowHeight)
        .fill('#f8fafc');
    }

    let x = startX;
    row.forEach((cell, idx) => {
      doc
        .font('Helvetica')
        .fontSize(8)
        .fillColor('#0f172a')
        .text(cell, x + 5, y + 5, {
          width: colWidths[idx] - 10,
          align: alignments?.[idx] ?? 'left',
          lineBreak: false,
          ellipsis: true,
        });
      x += colWidths[idx];
    });

    doc
      .moveTo(startX, y + rowHeight)
      .lineTo(startX + colWidths.reduce((a, b) => a + b, 0), y + rowHeight)
      .lineWidth(0.4)
      .strokeColor('#e2e8f0')
      .stroke();

    doc.y = y + rowHeight;
  });

  doc.moveDown(0.5);
}

export async function generateProjectPdfBuffer(): Promise<Buffer> {
  const [analytics, schema] = await Promise.all([getAnalytics(), getSchemaMetadata()]);

  return new Promise<Buffer>((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margin: 44,
      bufferPages: true,
      info: {
        Title: 'ScholarDB — Student Performance & Study Factors DBMS',
        Author: 'RICHARD BENSON RAJ.B.A, AJAY.B, S.MOHAMED ASFARALI',
        Subject: 'DBMS Project Software Model & Analytics Report',
      },
    });

    const chunks: Buffer[] = [];
    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('error', (err) => reject(err));
    doc.on('end', () => resolve(Buffer.concat(chunks)));

    const usableWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;

    // Cover / Top Banner
    doc
      .font('Helvetica-Bold')
      .fontSize(19)
      .fillColor('#0f172a')
      .text('ScholarDB — Student Performance & Study Factors DBMS');
    doc.moveDown(0.25);
    doc
      .font('Helvetica')
      .fontSize(10)
      .fillColor('#334155')
      .text('Relational Database Management System Software Model & Analytics Module');
    doc.moveDown(0.35);
    doc
      .font('Helvetica-Bold')
      .fontSize(9.5)
      .fillColor('#1d4ed8')
      .text('Presented by: RICHARD BENSON RAJ.B.A  ·  AJAY.B  ·  S.MOHAMED ASFARALI');
    doc.moveDown(0.2);
    doc
      .font('Helvetica')
      .fontSize(8.5)
      .fillColor('#64748b')
      .text(
        'Stack: React 19 + TypeScript + Tailwind CSS (Frontend)  |  Node.js + Express.js + SQLite sql.js (Backend)'
      );

    const bannerY = doc.y + 6;
    doc
      .moveTo(doc.page.margins.left, bannerY)
      .lineTo(doc.page.width - doc.page.margins.right, bannerY)
      .lineWidth(1.2)
      .strokeColor('#1d4ed8')
      .stroke();
    doc.y = bannerY + 12;

    // Section 1: Live Dataset KPIs & Department Summary
    drawSectionHeading(
      doc,
      '1. Live Database Metrics & Cohort Summary',
      'Computed dynamically from SQLite views v_student_performance_summary and v_factor_impact_by_mode'
    );

    drawTable(
      doc,
      ['Metric', 'Value', 'Context'],
      [
        ['Enrolled Students', String(analytics.kpis.totalStudents), '4 academic departments'],
        ['Course Enrollments', String(analytics.kpis.totalEnrollments), 'Associative M:N records with trigger-computed grades'],
        ['Study Session Logs', String(analytics.kpis.totalStudyLogs), 'Atomic time-series study activity records'],
        ['Mean Final Exam Score', `${analytics.kpis.meanFinalScore.toFixed(1)}%`, `OLS model R² = ${analytics.regressionModel.rSquared.toFixed(3)}`],
        ['Mean Weekly Study Hours', `${analytics.kpis.meanStudyHours.toFixed(1)} hrs/wk`, 'Self-reported & logged weekly study commitment'],
        ['Mean Lecture Attendance', `${analytics.kpis.meanAttendance.toFixed(1)}%`, 'Enforced CHECK (0 to 100)'],
        ['At-Risk Flagged Students', String(analytics.kpis.atRiskCount), 'Score < 62% or Attendance < 74%'],
      ],
      [165, 95, usableWidth - 260],
      ['left', 'right', 'left']
    );

    drawTable(
      doc,
      ['Dept', 'Department Name', 'Students', 'Mean Study', 'Attendance', 'Mean Score', 'At Risk'],
      analytics.departmentSummary.map((d) => [
        d.dept_code,
        d.dept_name,
        String(d.student_count),
        `${d.mean_study_hours}h`,
        `${d.mean_attendance_pct}%`,
        `${d.mean_final_score}%`,
        String(d.at_risk_count),
      ]),
      [48, 165, 55, 65, 65, 65, usableWidth - 463],
      ['left', 'left', 'right', 'right', 'right', 'right', 'right']
    );

    // Section 2: Study Factor Correlations & OLS Regression
    drawSectionHeading(
      doc,
      '2. Study Factor Correlations & Predictive OLS Model',
      'Pearson correlation (r) and multiple linear regression fitted via normal equations on live SQLite tuples'
    );

    drawTable(
      doc,
      ['Study Factor', 'Unit', 'Cohort Mean', 'Pearson r', 'Relationship'],
      analytics.correlations.map((c) => [
        c.label,
        c.unit,
        String(c.meanValue),
        c.pearsonR >= 0 ? `+${c.pearsonR.toFixed(3)}` : c.pearsonR.toFixed(3),
        c.direction === 'positive' ? 'Positive Impact' : 'Negative Impact',
      ]),
      [165, 65, 80, 75, usableWidth - 385],
      ['left', 'left', 'right', 'right', 'left']
    );

    const reg = analytics.regressionModel;
    const w = reg.weights;
    ensureSpace(doc, 54);
    doc
      .font('Helvetica-Bold')
      .fontSize(9)
      .fillColor('#0f172a')
      .text(`Fitted Regression Equation (R² = ${reg.rSquared.toFixed(3)}, RMSE = ±${reg.rmse.toFixed(2)} pts):`);
    doc
      .font('Courier')
      .fontSize(8)
      .fillColor('#1e293b')
      .text(
        `Predicted_Score = ${reg.intercept} + (${w.weekly_study_hours} * StudyHrs) + (${w.attendance_pct} * Attendance%) + (${w.sleep_hours_avg} * SleepHrs) + (${w.distraction_hours_daily} * DistractionHrs) + (${w.practice_tests_per_course} * PracticeTests) + (${w.prior_gpa} * PriorGPA)`
      );
    doc.moveDown(0.6);

    drawTable(
      doc,
      ['Preferred Study Mode', 'Students', 'Mean Study Hrs', 'Mean Attendance', 'Mean Sleep', 'Mean Final Score'],
      analytics.modeSummary.map((m) => [
        m.preferred_mode,
        String(m.student_count),
        `${m.mean_study_hours} hrs`,
        `${m.mean_attendance_pct}%`,
        `${m.mean_sleep_hours} hrs`,
        `${m.mean_final_score}%`,
      ]),
      [125, 60, 80, 85, 75, usableWidth - 425],
      ['left', 'right', 'right', 'right', 'right', 'right']
    );

    // Section 3: 3NF Relational Schema
    drawSectionHeading(
      doc,
      '3. Relational Database Schema (3NF / BCNF)',
      '6 normalized base tables and 3 analytical views with PRAGMA foreign_keys = ON'
    );

    for (const tbl of schema.tables) {
      ensureSpace(doc, 90);
      doc
        .font('Helvetica-Bold')
        .fontSize(10)
        .fillColor('#0f172a')
        .text(`${tbl.name}  [${tbl.kind.toUpperCase()} · ${tbl.rowCount} rows]`);
      doc
        .font('Helvetica')
        .fontSize(8.5)
        .fillColor('#475569')
        .text(`${tbl.description} (${tbl.normalForm})`);
      doc.moveDown(0.2);

      const colRows = tbl.columns.map((col) => {
        const fk = tbl.foreignKeys.find((f) => f.from === col.name);
        const notes: string[] = [];
        if (col.pk === 1) notes.push('PRIMARY KEY');
        if (fk) notes.push(`FK -> ${fk.table}(${fk.to}) ON DELETE ${fk.on_delete}`);
        if (col.notnull === 1 && col.pk === 0) notes.push('NOT NULL');
        if (col.dflt_value !== null) notes.push(`DEFAULT ${col.dflt_value}`);
        return [col.name, col.type || 'NUMERIC', notes.join(', ') || 'Nullable'];
      });

      drawTable(
        doc,
        ['Column', 'Data Type', 'Keys & Constraints'],
        colRows,
        [145, 90, usableWidth - 235]
      );
    }

    // Section 4: Normalization & Database Triggers
    drawSectionHeading(
      doc,
      '4. Normalization Walkthrough (1NF to 3NF) & Active Triggers',
      'Elimination of repeating groups, partial dependencies, and transitive dependencies'
    );

    for (const norm of schema.normalizationNotes) {
      ensureSpace(doc, 65);
      doc
        .font('Helvetica-Bold')
        .fontSize(9.5)
        .fillColor('#1d4ed8')
        .text(`${norm.stage}: ${norm.title}`);
      doc
        .font('Helvetica')
        .fontSize(8.5)
        .fillColor('#334155')
        .text(norm.summary);
      doc
        .font('Courier')
        .fontSize(7.5)
        .fillColor('#0f172a')
        .text(norm.example);
      doc.moveDown(0.45);
    }

    for (const trg of schema.triggers) {
      ensureSpace(doc, 95);
      doc
        .font('Helvetica-Bold')
        .fontSize(9.5)
        .fillColor('#0f172a')
        .text(`Trigger: ${trg.name} (on ${trg.tbl_name})`);
      doc
        .font('Courier')
        .fontSize(7.5)
        .fillColor('#334155')
        .text(trg.sql);
      doc.moveDown(0.4);
    }

    // Section 5: Sample Cohort Records (Top Performers & At-Risk)
    drawSectionHeading(
      doc,
      '5. Cohort Snapshot: Top Performers & Early-Warning Students',
      'Live rows queried from v_student_performance_summary'
    );

    const sortedByScore = [...analytics.students].sort(
      (a, b) => b.avg_final_score - a.avg_final_score
    );
    const topFive = sortedByScore.slice(0, 6);
    const atRiskSample = sortedByScore
      .filter((s) => s.risk_status === 'At Risk')
      .slice(-6)
      .reverse();

    drawTable(
      doc,
      ['Roll No', 'Student Name', 'Dept', 'Mode', 'Study', 'Attend.', 'Distract.', 'Score', 'Status'],
      [...topFive, ...atRiskSample].map((s) => [
        s.roll_no,
        s.full_name,
        s.dept_code,
        s.preferred_mode,
        `${s.weekly_study_hours}h`,
        `${s.attendance_pct}%`,
        `${s.distraction_hours_daily}h`,
        `${s.avg_final_score}%`,
        s.risk_status,
      ]),
      [62, 112, 36, 62, 42, 46, 48, 46, usableWidth - 454],
      ['left', 'left', 'left', 'left', 'right', 'right', 'right', 'right', 'left']
    );

    // Section 6: Software Architecture & Workspace Modules
    drawSectionHeading(
      doc,
      '6. Software Model Modules & REST API Endpoints',
      'End-to-end architecture connecting React TypeScript UI to Express + SQLite'
    );

    drawTable(
      doc,
      ['Module / Endpoint', 'Purpose & DBMS Capability'],
      [
        ['Performance Dashboard', 'Department/mode filters, scatter plot + OLS line, Pearson r ranking, directory'],
        ['ER Schema & Normalization', 'Interactive ER topology diagram, DDL viewer, 1NF-3NF walkthrough, triggers'],
        ['SQL Query Console', 'Live SQLite sandbox supporting JOIN, Window Functions, CHECK tests, CSV export'],
        ['Table Browser & CRUD', 'Direct Insert, Update, and Delete across all 6 tables with FK lookups'],
        ['Study Factor Simulator', 'What-if OLS predictor with direct SQL UPDATE persistence to study_habits'],
        ['GET /api/analytics', 'Computes KPIs, Pearson correlations, department stats, and OLS weights'],
        ['POST /api/sql', 'Executes arbitrary SQLite DQL/DML/DDL statements and reports execution time'],
        ['POST /api/students/composite', 'Atomic BEGIN TRANSACTION inserting student, study_habits, and enrollment'],
        ['GET /api/download-zip/:part', 'Packages runnable Frontend, Backend, or Full Project ZIP archives'],
        ['GET /api/download-pdf', 'Generates this live DBMS module report as a PDF document'],
      ],
      [155, usableWidth - 155]
    );

    // Add page footers across all buffered pages
    const range = doc.bufferedPageRange();
    for (let i = range.start; i < range.start + range.count; i++) {
      doc.switchToPage(i);
      const footerY = doc.page.height - 28;
      doc
        .font('Helvetica')
        .fontSize(7.5)
        .fillColor('#64748b')
        .text(
          `ScholarDB DBMS Project  ·  Presented by RICHARD BENSON RAJ.B.A, AJAY.B, S.MOHAMED ASFARALI`,
          doc.page.margins.left,
          footerY,
          { width: usableWidth - 60, align: 'left', lineBreak: false }
        );
      doc
        .font('Helvetica')
        .fontSize(7.5)
        .fillColor('#64748b')
        .text(
          `Page ${i + 1} of ${range.count}`,
          doc.page.width - doc.page.margins.right - 60,
          footerY,
          { width: 60, align: 'right', lineBreak: false }
        );
    }

    doc.end();
  });
}
