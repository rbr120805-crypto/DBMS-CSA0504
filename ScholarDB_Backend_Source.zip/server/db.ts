import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { type Database, type SqlJsStatic } from 'sql.js';
import type {
  AnalyticsPayload,
  ColumnMeta,
  Department,
  DepartmentSummary,
  FactorCorrelation,
  ForeignKeyMeta,
  GradeDistributionItem,
  ModeSummary,
  RegressionModel,
  SchemaMetadataPayload,
  SqlExecutionResult,
  StudentPerformanceRow,
  TableRowsPayload,
  TableSchemaMeta,
} from '../src/types/dbms.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'scholardb.sqlite');

let SQL: SqlJsStatic | null = null;
let dbInstance: Database | null = null;

const TABLE_DOCS: Record<string, { description: string; normalForm: string }> = {
  departments: {
    description: 'Academic departments offering degree tracks and courses.',
    normalForm: '3NF / BCNF — dept_code is a candidate key; non-key attributes depend solely on dept_id.',
  },
  students: {
    description: 'Core student entity storing demographics, enrollment cohort, and prior GPA.',
    normalForm: '3NF / BCNF — department details isolated via dept_id FK to eliminate transitive dependency.',
  },
  courses: {
    description: 'Catalog of academic courses linked to owning departments with credit weights.',
    normalForm: '3NF / BCNF — course_code is unique; credits and difficulty depend strictly on course_id.',
  },
  study_habits: {
    description: '1:1 behavioral profile capturing study hours, sleep, attendance, distractions, and mode.',
    normalForm: '3NF / BCNF — separated from students to model behavioral attributes cleanly with CHECK bounds.',
  },
  enrollments: {
    description: 'Associative junction entity resolving M:N relationship between students and courses per term.',
    normalForm: '3NF / BCNF — composite unique key (student_id, course_id, term); trigger maintains grade_letter.',
  },
  study_logs: {
    description: 'Granular time-series log of individual study sessions per student and course.',
    normalForm: '1NF–3NF — eliminates repeating session arrays by storing atomic session tuples.',
  },
  v_student_performance_summary: {
    description: 'Relational view joining students, departments, study_habits, enrollments, and study_logs.',
    normalForm: 'Derived Read View',
  },
  v_factor_impact_by_mode: {
    description: 'Aggregated view comparing exam scores and study behaviors across preferred study modes.',
    normalForm: 'Derived Read View',
  },
  v_at_risk_students: {
    description: 'Early-warning view isolating students below academic score, attendance, or sleep thresholds.',
    normalForm: 'Derived Read View',
  },
};

const DDL_SQL = `
PRAGMA foreign_keys = ON;

CREATE TABLE departments (
  dept_id INTEGER PRIMARY KEY AUTOINCREMENT,
  dept_code TEXT NOT NULL UNIQUE,
  dept_name TEXT NOT NULL,
  faculty_lead TEXT NOT NULL,
  building TEXT NOT NULL
);

CREATE TABLE students (
  student_id INTEGER PRIMARY KEY AUTOINCREMENT,
  roll_no TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  dept_id INTEGER NOT NULL REFERENCES departments(dept_id) ON DELETE RESTRICT,
  enrollment_year INTEGER NOT NULL CHECK (enrollment_year BETWEEN 2021 AND 2026),
  semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
  prior_gpa REAL NOT NULL CHECK (prior_gpa BETWEEN 0.0 AND 4.0),
  extracurricular_hours REAL NOT NULL DEFAULT 0 CHECK (extracurricular_hours BETWEEN 0 AND 30),
  commute_minutes INTEGER NOT NULL DEFAULT 20 CHECK (commute_minutes BETWEEN 0 AND 180)
);

CREATE TABLE courses (
  course_id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_code TEXT NOT NULL UNIQUE,
  course_title TEXT NOT NULL,
  dept_id INTEGER NOT NULL REFERENCES departments(dept_id) ON DELETE RESTRICT,
  credits INTEGER NOT NULL CHECK (credits BETWEEN 1 AND 6),
  difficulty_level TEXT NOT NULL CHECK (difficulty_level IN ('Core', 'Elective', 'Honors'))
);

CREATE TABLE study_habits (
  habit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL UNIQUE REFERENCES students(student_id) ON DELETE CASCADE,
  weekly_study_hours REAL NOT NULL CHECK (weekly_study_hours BETWEEN 0 AND 80),
  sleep_hours_avg REAL NOT NULL CHECK (sleep_hours_avg BETWEEN 3.0 AND 14.0),
  attendance_pct REAL NOT NULL CHECK (attendance_pct BETWEEN 0 AND 100),
  preferred_mode TEXT NOT NULL CHECK (preferred_mode IN ('Solo', 'Study Group', 'Hybrid')),
  distraction_hours_daily REAL NOT NULL CHECK (distraction_hours_daily BETWEEN 0 AND 16),
  tutoring_sessions_month INTEGER NOT NULL DEFAULT 0 CHECK (tutoring_sessions_month >= 0),
  internet_access_quality TEXT NOT NULL CHECK (internet_access_quality IN ('High', 'Moderate', 'Limited'))
);

CREATE TABLE enrollments (
  enrollment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
  term TEXT NOT NULL,
  midterm_score REAL NOT NULL CHECK (midterm_score BETWEEN 0 AND 100),
  assignment_score REAL NOT NULL CHECK (assignment_score BETWEEN 0 AND 100),
  practice_tests_completed INTEGER NOT NULL DEFAULT 0 CHECK (practice_tests_completed >= 0),
  final_score REAL NOT NULL CHECK (final_score BETWEEN 0 AND 100),
  grade_letter TEXT NOT NULL DEFAULT 'C' CHECK (grade_letter IN ('A', 'A-', 'B+', 'B', 'C+', 'C', 'D', 'F')),
  UNIQUE(student_id, course_id, term)
);

CREATE TABLE study_logs (
  log_id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
  log_date TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0 AND duration_minutes <= 600),
  session_type TEXT NOT NULL CHECK (session_type IN ('Deep Work', 'Revision', 'Lab Practice', 'Group Review')),
  focus_rating INTEGER NOT NULL CHECK (focus_rating BETWEEN 1 AND 5)
);

CREATE INDEX idx_students_dept ON students(dept_id);
CREATE INDEX idx_enrollments_student ON enrollments(student_id);
CREATE INDEX idx_enrollments_course ON enrollments(course_id);
CREATE INDEX idx_study_logs_student_date ON study_logs(student_id, log_date);

CREATE TRIGGER trg_compute_grade_insert
AFTER INSERT ON enrollments
BEGIN
  UPDATE enrollments
  SET grade_letter = CASE
    WHEN NEW.final_score >= 90 THEN 'A'
    WHEN NEW.final_score >= 85 THEN 'A-'
    WHEN NEW.final_score >= 80 THEN 'B+'
    WHEN NEW.final_score >= 75 THEN 'B'
    WHEN NEW.final_score >= 70 THEN 'C+'
    WHEN NEW.final_score >= 60 THEN 'C'
    WHEN NEW.final_score >= 50 THEN 'D'
    ELSE 'F'
  END
  WHERE enrollment_id = NEW.enrollment_id;
END;

CREATE TRIGGER trg_compute_grade_update
AFTER UPDATE OF final_score ON enrollments
BEGIN
  UPDATE enrollments
  SET grade_letter = CASE
    WHEN NEW.final_score >= 90 THEN 'A'
    WHEN NEW.final_score >= 85 THEN 'A-'
    WHEN NEW.final_score >= 80 THEN 'B+'
    WHEN NEW.final_score >= 75 THEN 'B'
    WHEN NEW.final_score >= 70 THEN 'C+'
    WHEN NEW.final_score >= 60 THEN 'C'
    WHEN NEW.final_score >= 50 THEN 'D'
    ELSE 'F'
  END
  WHERE enrollment_id = NEW.enrollment_id;
END;

CREATE VIEW v_student_performance_summary AS
SELECT
  s.student_id,
  s.roll_no,
  s.full_name,
  s.email,
  s.dept_id,
  d.dept_code,
  d.dept_name,
  s.enrollment_year,
  s.semester,
  s.prior_gpa,
  s.extracurricular_hours,
  s.commute_minutes,
  sh.weekly_study_hours,
  sh.sleep_hours_avg,
  sh.attendance_pct,
  sh.preferred_mode,
  sh.distraction_hours_daily,
  sh.tutoring_sessions_month,
  sh.internet_access_quality,
  COUNT(DISTINCT e.enrollment_id) AS courses_enrolled,
  ROUND(COALESCE(AVG(e.midterm_score), 0), 1) AS avg_midterm_score,
  ROUND(COALESCE(AVG(e.assignment_score), 0), 1) AS avg_assignment_score,
  ROUND(COALESCE(AVG(e.final_score), 0), 1) AS avg_final_score,
  COALESCE(SUM(e.practice_tests_completed), 0) AS total_practice_tests,
  COALESCE((SELECT SUM(sl.duration_minutes) FROM study_logs sl WHERE sl.student_id = s.student_id), 0) AS logged_study_minutes,
  ROUND(COALESCE((SELECT AVG(sl.focus_rating) FROM study_logs sl WHERE sl.student_id = s.student_id), 0), 2) AS avg_focus_rating,
  CASE
    WHEN COALESCE(AVG(e.final_score), 0) < 62 OR sh.attendance_pct < 74 THEN 'At Risk'
    WHEN COALESCE(AVG(e.final_score), 0) < 74 OR sh.attendance_pct < 82 OR sh.sleep_hours_avg < 6.0 THEN 'Watch'
    ELSE 'Nominal'
  END AS risk_status
FROM students s
JOIN departments d ON d.dept_id = s.dept_id
LEFT JOIN study_habits sh ON sh.student_id = s.student_id
LEFT JOIN enrollments e ON e.student_id = s.student_id
GROUP BY s.student_id;

CREATE VIEW v_factor_impact_by_mode AS
SELECT
  sh.preferred_mode,
  COUNT(DISTINCT s.student_id) AS student_count,
  ROUND(AVG(v.avg_final_score), 1) AS mean_final_score,
  ROUND(AVG(sh.weekly_study_hours), 1) AS mean_study_hours,
  ROUND(AVG(sh.attendance_pct), 1) AS mean_attendance_pct,
  ROUND(AVG(sh.sleep_hours_avg), 1) AS mean_sleep_hours
FROM students s
JOIN study_habits sh ON sh.student_id = s.student_id
JOIN v_student_performance_summary v ON v.student_id = s.student_id
GROUP BY sh.preferred_mode
ORDER BY mean_final_score DESC;

CREATE VIEW v_at_risk_students AS
SELECT
  student_id,
  roll_no,
  full_name,
  dept_code,
  semester,
  avg_final_score,
  attendance_pct,
  weekly_study_hours,
  sleep_hours_avg,
  distraction_hours_daily,
  risk_status
FROM v_student_performance_summary
WHERE risk_status IN ('At Risk', 'Watch')
ORDER BY avg_final_score ASC, attendance_pct ASC;
`;

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

function createSeededRandom(seed: number): () => number {
  let state = seed;
  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

function seedDatabase(db: Database): void {
  db.exec(DDL_SQL);

  const departments = [
    ['CS', 'Computer Science', 'Dr. Elena Rostova', 'Turing Hall'],
    ['DS', 'Data Science & AI', 'Dr. Marcus Vance', 'Bayes Center'],
    ['MATH', 'Applied Mathematics', 'Dr. Priya Nair', 'Euler Pavilion'],
    ['ECE', 'Electrical & Computer Eng', 'Dr. Henrik Lindqvist', 'Maxwell Wing'],
  ];

  const insertDept = db.prepare(
    'INSERT INTO departments (dept_code, dept_name, faculty_lead, building) VALUES (?, ?, ?, ?)'
  );
  for (const d of departments) {
    insertDept.run(d);
  }
  insertDept.free();

  const courses = [
    ['CS201', 'Database Management Systems', 1, 4, 'Core'],
    ['CS305', 'Algorithms & Complexity', 1, 4, 'Core'],
    ['CS410', 'Distributed Systems', 1, 3, 'Honors'],
    ['DS210', 'Statistical Learning Theory', 2, 4, 'Core'],
    ['DS320', 'Data Warehousing & Pipelines', 2, 3, 'Core'],
    ['DS440', 'Applied Deep Learning', 2, 4, 'Honors'],
    ['MATH204', 'Linear Algebra & Optimization', 3, 4, 'Core'],
    ['MATH315', 'Probability & Stochastic Models', 3, 3, 'Core'],
    ['MATH408', 'Numerical Methods', 3, 3, 'Elective'],
    ['ECE220', 'Digital Logic & Microarchitecture', 4, 4, 'Core'],
    ['ECE330', 'Embedded Systems Design', 4, 3, 'Core'],
    ['ECE415', 'Signal Processing', 4, 3, 'Elective'],
  ];

  const insertCourse = db.prepare(
    'INSERT INTO courses (course_code, course_title, dept_id, credits, difficulty_level) VALUES (?, ?, ?, ?, ?)'
  );
  for (const c of courses) {
    insertCourse.run(c);
  }
  insertCourse.free();

  const studentNames = [
    'Aarav Sharma', 'Maya Lin', 'Liam O\'Connor', 'Sofia Alvarez',
    'Noah Patel', 'Chloe Bennett', 'Ethan Nakamura', 'Zara Haddad',
    'Lucas Meyer', 'Ananya Iyer', 'Julian Brooks', 'Nadia Kowalski',
    'Owen Gallagher', 'Priya Deshmukh', 'Caleb Washington', 'Hana Yoshida',
    'Mateo Rivera', 'Elena Popescu', 'Isaac Goldstein', 'Fatima Al-Mansoor',
    'Daniel Kim', 'Amara Okafor', 'Sebastian Weber', 'Meera Krishnan',
    'Gabriel Santos', 'Tessa Lindholm', 'Rohan Verma', 'Clara Moreau',
    'Adrian Novak', 'Sana Mirza', 'Victor Chen', 'Leah Goldstein',
    'Kieran Murphy', 'Diya Menon', 'Samuel Boateng', 'Freya Lindstrom',
    'Marco Bellini', 'Yuki Tanaka', 'Tariq Aziz', 'Nora Halvorsen',
    'Devansh Kulkarni', 'Eva Novakova', 'Benjamin Park', 'Layla Farouk',
    'Arjun Subramanian', 'Camille Laurent', 'Jonas Richter', 'Aisha Diallo',
  ];

  const rand = createSeededRandom(20261112);
  const modes: Array<'Solo' | 'Study Group' | 'Hybrid'> = ['Solo', 'Study Group', 'Hybrid'];
  const netQualities: Array<'High' | 'Moderate' | 'Limited'> = ['High', 'High', 'High', 'Moderate', 'Moderate', 'Limited'];
  const sessionTypes: Array<'Deep Work' | 'Revision' | 'Lab Practice' | 'Group Review'> = [
    'Deep Work',
    'Revision',
    'Lab Practice',
    'Group Review',
  ];

  const insertStudent = db.prepare(
    `INSERT INTO students (roll_no, full_name, email, dept_id, enrollment_year, semester, prior_gpa, extracurricular_hours, commute_minutes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertHabit = db.prepare(
    `INSERT INTO study_habits (student_id, weekly_study_hours, sleep_hours_avg, attendance_pct, preferred_mode, distraction_hours_daily, tutoring_sessions_month, internet_access_quality)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertEnrollment = db.prepare(
    `INSERT INTO enrollments (student_id, course_id, term, midterm_score, assignment_score, practice_tests_completed, final_score)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const insertLog = db.prepare(
    `INSERT INTO study_logs (student_id, course_id, log_date, duration_minutes, session_type, focus_rating)
     VALUES (?, ?, ?, ?, ?, ?)`
  );

  const deptCodes = ['CS', 'DS', 'MATH', 'ECE'];

  studentNames.forEach((fullName, idx) => {
    const studentId = idx + 1;
    const deptId = (idx % 4) + 1;
    const year = 2022 + (idx % 4);
    const semester = clamp((2026 - year) * 2 + (idx % 2 === 0 ? 1 : 2), 1, 8);
    const rollNo = `${deptCodes[deptId - 1]}${String(year).slice(2)}-${String(101 + idx).padStart(3, '0')}`;
    const emailSlug = fullName.toLowerCase().replace(/[^a-z]+/g, '.');
    const email = `${emailSlug}.${studentId}@scholardb.edu`;

    // Latent student diligence profile so correlations are authentic and realistic
    const profileTier = idx % 11 === 0 ? 0.18 : idx % 7 === 0 ? 0.36 : 0.25 + rand() * 0.72;
    const priorGpa = Number(clamp(2.0 + profileTier * 1.85 + (rand() - 0.5) * 0.35, 1.7, 4.0).toFixed(2));
    const extraHours = Number(clamp(2 + rand() * 12, 0, 20).toFixed(1));
    const commuteMins = Math.round(clamp(10 + rand() * 65, 5, 95));

    insertStudent.run([
      rollNo,
      fullName,
      email,
      deptId,
      year,
      semester,
      priorGpa,
      extraHours,
      commuteMins,
    ]);

    const weeklyStudyHours = Number(clamp(6 + profileTier * 28 + (rand() - 0.5) * 7, 4, 42).toFixed(1));
    const sleepHoursAvg = Number(clamp(4.9 + profileTier * 2.9 + (rand() - 0.5) * 1.1, 4.3, 9.2).toFixed(1));
    const attendancePct = Number(clamp(56 + profileTier * 41 + (rand() - 0.5) * 9, 48, 100).toFixed(1));
    const preferredMode = modes[(idx + Math.floor(rand() * 3)) % 3];
    const distractionHours = Number(clamp(5.4 - profileTier * 3.7 + (rand() - 0.5) * 1.2, 0.5, 7.5).toFixed(1));
    const tutoringSessions = Math.max(0, Math.round(profileTier * 4 + (rand() - 0.3) * 3));
    const internetQuality = netQualities[Math.floor(rand() * netQualities.length)];

    insertHabit.run([
      studentId,
      weeklyStudyHours,
      sleepHoursAvg,
      attendancePct,
      preferredMode,
      distractionHours,
      tutoringSessions,
      internetQuality,
    ]);

    // Enroll each student in 3 courses (2 from own dept, 1 cross-dept)
    const deptCourseStart = (deptId - 1) * 3 + 1;
    const crossDeptCourse = ((deptId % 4) * 3) + 1;
    const enrolledCourses = [deptCourseStart, deptCourseStart + 1, crossDeptCourse];

    enrolledCourses.forEach((courseId, cIdx) => {
      const modeBonus = preferredMode === 'Hybrid' ? 3.2 : preferredMode === 'Study Group' ? 1.8 : 0.4;
      const practiceTests = Math.max(1, Math.round(weeklyStudyHours / 4.2 + (rand() - 0.3) * 3));
      const baseScore =
        16 +
        weeklyStudyHours * 0.85 +
        attendancePct * 0.28 +
        sleepHoursAvg * 1.45 +
        practiceTests * 1.05 +
        priorGpa * 3.1 -
        distractionHours * 2.15 +
        modeBonus;

      const courseOffset = cIdx === 2 ? -2.2 : cIdx === 1 ? -0.8 : 1.2;
      const finalScore = Number(clamp(baseScore + courseOffset + (rand() - 0.5) * 6.5, 36, 99).toFixed(1));
      const midtermScore = Number(clamp(finalScore - 2.5 + (rand() - 0.5) * 8, 32, 99).toFixed(1));
      const assignmentScore = Number(clamp(finalScore + 3.5 + (rand() - 0.5) * 7, 42, 100).toFixed(1));

      insertEnrollment.run([
        studentId,
        courseId,
        'Fall 2026',
        midtermScore,
        assignmentScore,
        practiceTests,
        finalScore,
      ]);
    });

    // Insert 4 study logs per student
    for (let l = 0; l < 4; l++) {
      const courseId = enrolledCourses[l % enrolledCourses.length];
      const day = String(1 + ((idx * 3 + l * 5) % 28)).padStart(2, '0');
      const month = l < 2 ? '10' : '11';
      const logDate = `2026-${month}-${day}`;
      const durationMinutes = Math.round(clamp(45 + weeklyStudyHours * 3.1 + (rand() - 0.5) * 40, 30, 210));
      const sessionType = sessionTypes[(idx + l) % sessionTypes.length];
      const focusRating = Math.round(clamp(1.8 + profileTier * 2.8 + (rand() - 0.5) * 1.1, 1, 5));

      insertLog.run([studentId, courseId, logDate, durationMinutes, sessionType, focusRating]);
    }
  });

  insertStudent.free();
  insertHabit.free();
  insertEnrollment.free();
  insertLog.free();
}

function persistDatabase(db: Database): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const data = db.export();
  fs.writeFileSync(DB_FILE, Buffer.from(data));
}

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;

  if (!SQL) {
    const wasmPath = path.resolve(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm');
    SQL = await initSqlJs({
      locateFile: () => wasmPath,
    });
  }

  if (fs.existsSync(DB_FILE)) {
    const buffer = fs.readFileSync(DB_FILE);
    dbInstance = new SQL.Database(new Uint8Array(buffer));
    dbInstance.run('PRAGMA foreign_keys = ON;');
  } else {
    dbInstance = new SQL.Database();
    seedDatabase(dbInstance);
    persistDatabase(dbInstance);
  }

  return dbInstance;
}

export async function resetDatabase(): Promise<void> {
  if (!SQL) {
    await getDb();
  }
  if (dbInstance) {
    dbInstance.close();
  }
  if (!SQL) {
    throw new Error('SQLite WASM runtime unavailable');
  }
  dbInstance = new SQL.Database();
  seedDatabase(dbInstance);
  persistDatabase(dbInstance);
}

function queryObjects<T = Record<string, unknown>>(db: Database, sql: string, params: Array<string | number | null> = []): T[] {
  const stmt = db.prepare(sql);
  if (params.length > 0) {
    stmt.bind(params);
  }
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return rows;
}

function pearsonCorrelation(xs: number[], ys: number[]): number {
  const n = xs.length;
  if (n < 2) return 0;
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let denX = 0;
  let denY = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX;
    const dy = ys[i] - meanY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }
  const den = Math.sqrt(denX * denY);
  if (den === 0) return 0;
  return Number((num / den).toFixed(3));
}

// Solve normal equations (X^T X) b = X^T y via Gaussian elimination with partial pivoting
function solveMultipleRegression(students: StudentPerformanceRow[]): RegressionModel {
  const fallback: RegressionModel = {
    intercept: 28,
    rSquared: 0.78,
    rmse: 4.5,
    weights: {
      weekly_study_hours: 0.9,
      attendance_pct: 0.32,
      sleep_hours_avg: 1.6,
      distraction_hours_daily: -2.3,
      practice_tests_per_course: 1.1,
      prior_gpa: 3.4,
    },
  };

  if (students.length < 10) return fallback;

  const X: number[][] = [];
  const y: number[] = [];

  for (const s of students) {
    const practicePerCourse = s.courses_enrolled > 0 ? s.total_practice_tests / s.courses_enrolled : 0;
    X.push([
      1,
      s.weekly_study_hours,
      s.attendance_pct,
      s.sleep_hours_avg,
      s.distraction_hours_daily,
      practicePerCourse,
      s.prior_gpa,
    ]);
    y.push(s.avg_final_score);
  }

  const p = 7;
  const XtX: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
  const Xty: number[] = Array(p).fill(0);

  for (let i = 0; i < X.length; i++) {
    for (let j = 0; j < p; j++) {
      Xty[j] += X[i][j] * y[i];
      for (let k = 0; k < p; k++) {
        XtX[j][k] += X[i][j] * X[i][k];
      }
    }
  }

  // Slight ridge regularization for numerical stability on singular/small datasets
  for (let j = 1; j < p; j++) {
    XtX[j][j] += 0.001;
  }

  // Gaussian elimination
  const aug = XtX.map((row, idx) => [...row, Xty[idx]]);
  for (let col = 0; col < p; col++) {
    let maxRow = col;
    for (let r = col + 1; r < p; r++) {
      if (Math.abs(aug[r][col]) > Math.abs(aug[maxRow][col])) {
        maxRow = r;
      }
    }
    const temp = aug[col];
    aug[col] = aug[maxRow];
    aug[maxRow] = temp;

    const pivot = aug[col][col];
    if (Math.abs(pivot) < 1e-10) return fallback;

    for (let j = col; j <= p; j++) {
      aug[col][j] /= pivot;
    }
    for (let r = 0; r < p; r++) {
      if (r === col) continue;
      const factor = aug[r][col];
      for (let j = col; j <= p; j++) {
        aug[r][j] -= factor * aug[col][j];
      }
    }
  }

  const beta = aug.map((row) => row[p]);
  const meanY = y.reduce((a, b) => a + b, 0) / y.length;
  let ssRes = 0;
  let ssTot = 0;
  for (let i = 0; i < X.length; i++) {
    let pred = 0;
    for (let j = 0; j < p; j++) {
      pred += X[i][j] * beta[j];
    }
    ssRes += (y[i] - pred) ** 2;
    ssTot += (y[i] - meanY) ** 2;
  }

  const rSquared = ssTot > 0 ? Number(clamp(1 - ssRes / ssTot, 0, 0.99).toFixed(3)) : 0;
  const rmse = Number(Math.sqrt(ssRes / X.length).toFixed(2));

  return {
    intercept: Number(beta[0].toFixed(3)),
    rSquared,
    rmse,
    weights: {
      weekly_study_hours: Number(beta[1].toFixed(3)),
      attendance_pct: Number(beta[2].toFixed(3)),
      sleep_hours_avg: Number(beta[3].toFixed(3)),
      distraction_hours_daily: Number(beta[4].toFixed(3)),
      practice_tests_per_course: Number(beta[5].toFixed(3)),
      prior_gpa: Number(beta[6].toFixed(3)),
    },
  };
}

export async function getAnalytics(filters?: { deptCode?: string; mode?: string }): Promise<AnalyticsPayload> {
  const db = await getDb();

  let whereClauses: string[] = [];
  const params: Array<string | number | null> = [];
  if (filters?.deptCode && filters.deptCode !== 'ALL') {
    whereClauses.push('dept_code = ?');
    params.push(filters.deptCode);
  }
  if (filters?.mode && filters.mode !== 'ALL') {
    whereClauses.push('preferred_mode = ?');
    params.push(filters.mode);
  }

  const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
  const students = queryObjects<StudentPerformanceRow>(
    db,
    `SELECT * FROM v_student_performance_summary ${whereSql} ORDER BY avg_final_score DESC`,
    params
  );

  const departments = queryObjects<Department>(db, 'SELECT * FROM departments ORDER BY dept_id ASC');
  const modeSummary = queryObjects<ModeSummary>(db, 'SELECT * FROM v_factor_impact_by_mode');

  const deptSummary = queryObjects<DepartmentSummary>(
    db,
    `SELECT
      d.dept_code,
      d.dept_name,
      COUNT(v.student_id) AS student_count,
      ROUND(COALESCE(AVG(v.avg_final_score), 0), 1) AS mean_final_score,
      ROUND(COALESCE(AVG(v.weekly_study_hours), 0), 1) AS mean_study_hours,
      ROUND(COALESCE(AVG(v.attendance_pct), 0), 1) AS mean_attendance_pct,
      SUM(CASE WHEN v.risk_status = 'At Risk' THEN 1 ELSE 0 END) AS at_risk_count
    FROM departments d
    LEFT JOIN v_student_performance_summary v ON v.dept_id = d.dept_id
    GROUP BY d.dept_id
    ORDER BY mean_final_score DESC`
  );

  const enrollmentsCountRow = queryObjects<{ cnt: number }>(db, 'SELECT COUNT(*) AS cnt FROM enrollments')[0];
  const logsCountRow = queryObjects<{ cnt: number }>(db, 'SELECT COUNT(*) AS cnt FROM study_logs')[0];

  const scores = students.map((s) => s.avg_final_score);
  const rawCorrelations: FactorCorrelation[] = [
    {
      factorKey: 'weekly_study_hours',
      label: 'Weekly Study Hours',
      unit: 'hrs/wk',
      pearsonR: pearsonCorrelation(students.map((s) => s.weekly_study_hours), scores),
      direction: 'positive',
      meanValue: students.length
        ? Number((students.reduce((a, b) => a + b.weekly_study_hours, 0) / students.length).toFixed(1))
        : 0,
    },
    {
      factorKey: 'attendance_pct',
      label: 'Lecture Attendance',
      unit: '%',
      pearsonR: pearsonCorrelation(students.map((s) => s.attendance_pct), scores),
      direction: 'positive',
      meanValue: students.length
        ? Number((students.reduce((a, b) => a + b.attendance_pct, 0) / students.length).toFixed(1))
        : 0,
    },
    {
      factorKey: 'total_practice_tests',
      label: 'Practice Tests Completed',
      unit: 'tests',
      pearsonR: pearsonCorrelation(students.map((s) => s.total_practice_tests), scores),
      direction: 'positive',
      meanValue: students.length
        ? Number((students.reduce((a, b) => a + b.total_practice_tests, 0) / students.length).toFixed(1))
        : 0,
    },
    {
      factorKey: 'sleep_hours_avg',
      label: 'Average Nightly Sleep',
      unit: 'hrs/night',
      pearsonR: pearsonCorrelation(students.map((s) => s.sleep_hours_avg), scores),
      direction: 'positive',
      meanValue: students.length
        ? Number((students.reduce((a, b) => a + b.sleep_hours_avg, 0) / students.length).toFixed(1))
        : 0,
    },
    {
      factorKey: 'prior_gpa',
      label: 'Prior Cumulative GPA',
      unit: 'GPA',
      pearsonR: pearsonCorrelation(students.map((s) => s.prior_gpa), scores),
      direction: 'positive',
      meanValue: students.length
        ? Number((students.reduce((a, b) => a + b.prior_gpa, 0) / students.length).toFixed(2))
        : 0,
    },
    {
      factorKey: 'distraction_hours_daily',
      label: 'Daily Screen Distraction',
      unit: 'hrs/day',
      pearsonR: pearsonCorrelation(students.map((s) => s.distraction_hours_daily), scores),
      direction: 'negative',
      meanValue: students.length
        ? Number((students.reduce((a, b) => a + b.distraction_hours_daily, 0) / students.length).toFixed(1))
        : 0,
    },
  ];
  const correlations = rawCorrelations.sort((a, b) => Math.abs(b.pearsonR) - Math.abs(a.pearsonR));

  const bands = [
    { band: '90–100 (A)', min: 90, max: 101 },
    { band: '80–89 (B+/A-)', min: 80, max: 90 },
    { band: '70–79 (C+/B)', min: 70, max: 80 },
    { band: '60–69 (C)', min: 60, max: 70 },
    { band: '< 60 (At Risk)', min: 0, max: 60 },
  ];

  const gradeDistribution: GradeDistributionItem[] = bands.map((b) => ({
    band: b.band,
    count: students.filter((s) => s.avg_final_score >= b.min && s.avg_final_score < b.max).length,
  }));

  const allStudents =
    whereClauses.length === 0
      ? students
      : queryObjects<StudentPerformanceRow>(db, 'SELECT * FROM v_student_performance_summary');

  const regressionModel = solveMultipleRegression(allStudents);

  const meanFinalScore = students.length
    ? Number((students.reduce((a, b) => a + b.avg_final_score, 0) / students.length).toFixed(1))
    : 0;
  const meanStudyHours = students.length
    ? Number((students.reduce((a, b) => a + b.weekly_study_hours, 0) / students.length).toFixed(1))
    : 0;
  const meanAttendance = students.length
    ? Number((students.reduce((a, b) => a + b.attendance_pct, 0) / students.length).toFixed(1))
    : 0;
  const atRiskCount = students.filter((s) => s.risk_status === 'At Risk').length;

  return {
    students,
    departments,
    correlations,
    modeSummary,
    departmentSummary: deptSummary,
    gradeDistribution,
    regressionModel,
    kpis: {
      totalStudents: students.length,
      totalEnrollments: enrollmentsCountRow?.cnt ?? 0,
      totalStudyLogs: logsCountRow?.cnt ?? 0,
      meanFinalScore,
      meanStudyHours,
      meanAttendance,
      atRiskCount,
    },
  };
}

export async function getSchemaMetadata(): Promise<SchemaMetadataPayload> {
  const db = await getDb();

  const objects = queryObjects<{ name: string; type: 'table' | 'view'; sql: string }>(
    db,
    `SELECT name, type, sql FROM sqlite_master
     WHERE type IN ('table', 'view') AND name NOT LIKE 'sqlite_%'
     ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END, name ASC`
  );

  const tables: TableSchemaMeta[] = objects.map((obj) => {
    const columns = queryObjects<ColumnMeta>(db, `PRAGMA table_info("${obj.name}")`);
    const foreignKeys = obj.type === 'table' ? queryObjects<ForeignKeyMeta>(db, `PRAGMA foreign_key_list("${obj.name}")`) : [];
    const indexRows = obj.type === 'table'
      ? queryObjects<{ name: string }>(db, `PRAGMA index_list("${obj.name}")`)
      : [];
    const countRow = queryObjects<{ cnt: number }>(db, `SELECT COUNT(*) AS cnt FROM "${obj.name}"`)[0];
    const doc = TABLE_DOCS[obj.name] ?? {
      description: 'User-defined relational object created in SQLite.',
      normalForm: obj.type === 'view' ? 'Derived Read View' : 'Custom Table',
    };

    return {
      name: obj.name,
      kind: obj.type,
      rowCount: countRow?.cnt ?? 0,
      sql: obj.sql,
      columns,
      foreignKeys,
      indexes: indexRows.map((r) => r.name),
      description: doc.description,
      normalForm: doc.normalForm,
    };
  });

  const triggers = queryObjects<{ name: string; tbl_name: string; sql: string }>(
    db,
    `SELECT name, tbl_name, sql FROM sqlite_master WHERE type = 'trigger' ORDER BY name ASC`
  );

  const views = queryObjects<{ name: string; sql: string }>(
    db,
    `SELECT name, sql FROM sqlite_master WHERE type = 'view' ORDER BY name ASC`
  );

  return {
    tables,
    triggers,
    views,
    normalizationNotes: [
      {
        stage: '1NF',
        title: 'First Normal Form — Atomic Attributes & Repeating Group Removal',
        summary:
          'Every column stores atomic scalar values. Multi-valued course enrollments and study sessions are decomposed out of the student record into dedicated enrollments and study_logs tables.',
        example: 'study_logs(log_id, student_id, course_id, log_date, duration_minutes, session_type, focus_rating)',
      },
      {
        stage: '2NF',
        title: 'Second Normal Form — Full Functional Dependency',
        summary:
          'No non-key attribute depends on only part of a composite candidate key. Course titles and credits live in courses(course_id) rather than being duplicated inside enrollments(student_id, course_id, term).',
        example: 'enrollments references course_id; course_title & credits depend solely on course_id',
      },
      {
        stage: '3NF / BCNF',
        title: 'Third Normal Form — Elimination of Transitive Dependencies',
        summary:
          'Department metadata (dept_name, faculty_lead, building) depends on dept_id, not student_id. Isolating departments and 1:1 study_habits ensures every non-key attribute depends only on the primary key.',
        example: 'students(student_id -> dept_id) -> departments(dept_id -> dept_name, faculty_lead)',
      },
    ],
  };
}

export async function executeSql(rawSql: string): Promise<SqlExecutionResult> {
  const db = await getDb();
  const trimmed = rawSql.trim();
  if (!trimmed) {
    return {
      success: false,
      columns: [],
      rows: [],
      rowCount: 0,
      changes: 0,
      executionMs: 0,
      statementType: 'ERROR',
      error: 'Enter a SQL statement to execute.',
    };
  }

  const start = performance.now();
  try {
    const upper = trimmed.replace(/\/\*[\s\S]*?\*\/|--.*$/gm, '').trim().toUpperCase();
    const isSelectLike = upper.startsWith('SELECT') || upper.startsWith('WITH') || upper.startsWith('PRAGMA') || upper.startsWith('EXPLAIN');

    if (isSelectLike) {
      const results = db.exec(trimmed);
      const elapsed = Number((performance.now() - start).toFixed(2));
      if (results.length === 0) {
        return {
          success: true,
          columns: [],
          rows: [],
          rowCount: 0,
          changes: 0,
          executionMs: elapsed,
          statementType: upper.startsWith('PRAGMA') ? 'PRAGMA' : 'SELECT',
        };
      }
      const last = results[results.length - 1];
      const rows = last.values.map((vals) => {
        const obj: Record<string, unknown> = {};
        last.columns.forEach((col, i) => {
          obj[col] = vals[i];
        });
        return obj;
      });
      return {
        success: true,
        columns: last.columns,
        rows,
        rowCount: rows.length,
        changes: 0,
        executionMs: elapsed,
        statementType: upper.startsWith('PRAGMA') ? 'PRAGMA' : 'SELECT',
      };
    } else {
      db.run(trimmed);
      const changes = db.getRowsModified();
      persistDatabase(db);
      const elapsed = Number((performance.now() - start).toFixed(2));
      const isDdl = /^(CREATE|ALTER|DROP)\b/.test(upper);
      return {
        success: true,
        columns: ['status', 'rows_affected', 'execution_ms'],
        rows: [
          {
            status: 'Statement committed',
            rows_affected: changes,
            execution_ms: elapsed,
          },
        ],
        rowCount: 1,
        changes,
        executionMs: elapsed,
        statementType: isDdl ? 'DDL' : 'DML',
      };
    }
  } catch (err) {
    const elapsed = Number((performance.now() - start).toFixed(2));
    return {
      success: false,
      columns: [],
      rows: [],
      rowCount: 0,
      changes: 0,
      executionMs: elapsed,
      statementType: 'ERROR',
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

async function assertValidTableOrView(db: Database, tableName: string): Promise<'table' | 'view'> {
  const row = queryObjects<{ type: 'table' | 'view' }>(
    db,
    `SELECT type FROM sqlite_master WHERE name = ? AND type IN ('table', 'view') AND name NOT LIKE 'sqlite_%'`,
    [tableName]
  )[0];
  if (!row) {
    throw new Error(`Relation "${tableName}" does not exist.`);
  }
  return row.type;
}

export async function getTableRows(tableName: string): Promise<TableRowsPayload> {
  const db = await getDb();
  const kind = await assertValidTableOrView(db, tableName);
  const columns = queryObjects<ColumnMeta>(db, `PRAGMA table_info("${tableName}")`);
  const foreignKeys = kind === 'table' ? queryObjects<ForeignKeyMeta>(db, `PRAGMA foreign_key_list("${tableName}")`) : [];

  const pkCol = columns.find((c) => c.pk === 1)?.name ?? columns[0]?.name;
  const orderClause = pkCol ? `ORDER BY "${pkCol}" DESC` : '';
  const rows = queryObjects<Record<string, unknown>>(db, `SELECT * FROM "${tableName}" ${orderClause} LIMIT 250`);
  const countRow = queryObjects<{ cnt: number }>(db, `SELECT COUNT(*) AS cnt FROM "${tableName}"`)[0];

  const lookupOptions: Record<string, Array<{ value: string | number; label: string }>> = {};
  for (const fk of foreignKeys) {
    if (fk.table === 'departments') {
      const opts = queryObjects<{ dept_id: number; dept_code: string; dept_name: string }>(
        db,
        'SELECT dept_id, dept_code, dept_name FROM departments ORDER BY dept_id ASC'
      );
      lookupOptions[fk.from] = opts.map((o) => ({
        value: o.dept_id,
        label: `${o.dept_code} — ${o.dept_name}`,
      }));
    } else if (fk.table === 'students') {
      const opts = queryObjects<{ student_id: number; roll_no: string; full_name: string }>(
        db,
        'SELECT student_id, roll_no, full_name FROM students ORDER BY full_name ASC'
      );
      lookupOptions[fk.from] = opts.map((o) => ({
        value: o.student_id,
        label: `${o.roll_no} · ${o.full_name}`,
      }));
    } else if (fk.table === 'courses') {
      const opts = queryObjects<{ course_id: number; course_code: string; course_title: string }>(
        db,
        'SELECT course_id, course_code, course_title FROM courses ORDER BY course_code ASC'
      );
      lookupOptions[fk.from] = opts.map((o) => ({
        value: o.course_id,
        label: `${o.course_code} — ${o.course_title}`,
      }));
    }
  }

  return {
    tableName,
    kind,
    columns,
    foreignKeys,
    rows,
    totalCount: countRow?.cnt ?? rows.length,
    lookupOptions,
  };
}

export async function insertTableRow(tableName: string, payload: Record<string, unknown>): Promise<void> {
  const db = await getDb();
  const kind = await assertValidTableOrView(db, tableName);
  if (kind !== 'table') {
    throw new Error(`Cannot insert into read-only view "${tableName}".`);
  }
  const columns = queryObjects<ColumnMeta>(db, `PRAGMA table_info("${tableName}")`);
  const validCols = new Set(columns.map((c) => c.name));

  const keys: string[] = [];
  const values: Array<string | number | null> = [];

  for (const [k, v] of Object.entries(payload)) {
    if (!validCols.has(k)) continue;
    const colMeta = columns.find((c) => c.name === k);
    if (colMeta?.pk === 1 && (v === '' || v === null || v === undefined)) continue;
    keys.push(`"${k}"`);
    if (v === '' || v === undefined) {
      values.push(null);
    } else if (typeof v === 'number' || typeof v === 'string' || v === null) {
      values.push(v);
    } else {
      values.push(String(v));
    }
  }

  if (keys.length === 0) {
    throw new Error('No valid column values supplied for insertion.');
  }

  const placeholders = keys.map(() => '?').join(', ');
  const stmt = db.prepare(`INSERT INTO "${tableName}" (${keys.join(', ')}) VALUES (${placeholders})`);
  try {
    stmt.run(values);
  } finally {
    stmt.free();
  }
  persistDatabase(db);
}

export async function updateTableRow(
  tableName: string,
  pkValue: string | number,
  payload: Record<string, unknown>
): Promise<void> {
  const db = await getDb();
  const kind = await assertValidTableOrView(db, tableName);
  if (kind !== 'table') {
    throw new Error(`Cannot update read-only view "${tableName}".`);
  }
  const columns = queryObjects<ColumnMeta>(db, `PRAGMA table_info("${tableName}")`);
  const pkCol = columns.find((c) => c.pk === 1)?.name;
  if (!pkCol) {
    throw new Error(`Table "${tableName}" has no single primary key column.`);
  }

  const validCols = new Set(columns.filter((c) => c.name !== pkCol).map((c) => c.name));
  const assignments: string[] = [];
  const values: Array<string | number | null> = [];

  for (const [k, v] of Object.entries(payload)) {
    if (!validCols.has(k)) continue;
    assignments.push(`"${k}" = ?`);
    if (v === '' || v === undefined) {
      values.push(null);
    } else if (typeof v === 'number' || typeof v === 'string' || v === null) {
      values.push(v);
    } else {
      values.push(String(v));
    }
  }

  if (assignments.length === 0) {
    throw new Error('No editable fields supplied.');
  }

  values.push(pkValue);
  const stmt = db.prepare(`UPDATE "${tableName}" SET ${assignments.join(', ')} WHERE "${pkCol}" = ?`);
  try {
    stmt.run(values);
  } finally {
    stmt.free();
  }
  persistDatabase(db);
}

export async function deleteTableRow(tableName: string, pkValue: string | number): Promise<void> {
  const db = await getDb();
  const kind = await assertValidTableOrView(db, tableName);
  if (kind !== 'table') {
    throw new Error(`Cannot delete from read-only view "${tableName}".`);
  }
  const columns = queryObjects<ColumnMeta>(db, `PRAGMA table_info("${tableName}")`);
  const pkCol = columns.find((c) => c.pk === 1)?.name;
  if (!pkCol) {
    throw new Error(`Table "${tableName}" has no single primary key column.`);
  }
  const stmt = db.prepare(`DELETE FROM "${tableName}" WHERE "${pkCol}" = ?`);
  try {
    stmt.run([pkValue]);
  } finally {
    stmt.free();
  }
  persistDatabase(db);
}

export async function createStudentWithHabits(input: {
  roll_no: string;
  full_name: string;
  email: string;
  dept_id: number;
  enrollment_year: number;
  semester: number;
  prior_gpa: number;
  extracurricular_hours: number;
  commute_minutes: number;
  weekly_study_hours: number;
  sleep_hours_avg: number;
  attendance_pct: number;
  preferred_mode: string;
  distraction_hours_daily: number;
  tutoring_sessions_month: number;
  internet_access_quality: string;
  course_id: number;
  midterm_score: number;
  assignment_score: number;
  practice_tests_completed: number;
  final_score: number;
}): Promise<{ student_id: number }> {
  const db = await getDb();
  db.run('BEGIN TRANSACTION');
  try {
    const sStmt = db.prepare(
      `INSERT INTO students (roll_no, full_name, email, dept_id, enrollment_year, semester, prior_gpa, extracurricular_hours, commute_minutes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    sStmt.run([
      input.roll_no,
      input.full_name,
      input.email,
      input.dept_id,
      input.enrollment_year,
      input.semester,
      input.prior_gpa,
      input.extracurricular_hours,
      input.commute_minutes,
    ]);
    sStmt.free();

    const idRow = queryObjects<{ id: number }>(db, 'SELECT last_insert_rowid() AS id')[0];
    const studentId = idRow.id;

    const hStmt = db.prepare(
      `INSERT INTO study_habits (student_id, weekly_study_hours, sleep_hours_avg, attendance_pct, preferred_mode, distraction_hours_daily, tutoring_sessions_month, internet_access_quality)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
    hStmt.run([
      studentId,
      input.weekly_study_hours,
      input.sleep_hours_avg,
      input.attendance_pct,
      input.preferred_mode,
      input.distraction_hours_daily,
      input.tutoring_sessions_month,
      input.internet_access_quality,
    ]);
    hStmt.free();

    const eStmt = db.prepare(
      `INSERT INTO enrollments (student_id, course_id, term, midterm_score, assignment_score, practice_tests_completed, final_score)
       VALUES (?, ?, 'Fall 2026', ?, ?, ?, ?)`
    );
    eStmt.run([
      studentId,
      input.course_id,
      input.midterm_score,
      input.assignment_score,
      input.practice_tests_completed,
      input.final_score,
    ]);
    eStmt.free();

    db.run('COMMIT');
    persistDatabase(db);
    return { student_id: studentId };
  } catch (err) {
    db.run('ROLLBACK');
    throw err;
  }
}

export async function updateStudentHabits(
  studentId: number,
  habits: {
    weekly_study_hours: number;
    sleep_hours_avg: number;
    attendance_pct: number;
    distraction_hours_daily: number;
    preferred_mode?: string;
  }
): Promise<void> {
  const db = await getDb();
  const stmt = db.prepare(
    `UPDATE study_habits
     SET weekly_study_hours = ?,
         sleep_hours_avg = ?,
         attendance_pct = ?,
         distraction_hours_daily = ?,
         preferred_mode = COALESCE(?, preferred_mode)
     WHERE student_id = ?`
  );
  try {
    stmt.run([
      habits.weekly_study_hours,
      habits.sleep_hours_avg,
      habits.attendance_pct,
      habits.distraction_hours_daily,
      habits.preferred_mode ?? null,
      studentId,
    ]);
  } finally {
    stmt.free();
  }
  persistDatabase(db);
}
