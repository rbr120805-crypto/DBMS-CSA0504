import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import {
  createStudentWithHabits,
  deleteTableRow,
  executeSql,
  getAnalytics,
  getDb,
  getSchemaMetadata,
  getTableRows,
  insertTableRow,
  resetDatabase,
  updateStudentHabits,
  updateTableRow,
} from './server/db.ts';
import { generateProjectPdfBuffer } from './server/pdf.ts';

async function startServer(): Promise<void> {
  await getDb();

  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/analytics', async (req, res) => {
    try {
      const deptCode = typeof req.query.dept === 'string' ? req.query.dept : undefined;
      const mode = typeof req.query.mode === 'string' ? req.query.mode : undefined;
      const payload = await getAnalytics({ deptCode, mode });
      res.json(payload);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to load analytics' });
    }
  });

  app.get('/api/schema', async (_req, res) => {
    try {
      const payload = await getSchemaMetadata();
      res.json(payload);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to load schema metadata' });
    }
  });

  app.post('/api/sql', async (req, res) => {
    try {
      const sql = typeof req.body?.sql === 'string' ? req.body.sql : '';
      const result = await executeSql(sql);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'SQL execution failed' });
    }
  });

  app.get('/api/tables/:tableName', async (req, res) => {
    try {
      const payload = await getTableRows(req.params.tableName);
      res.json(payload);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to read relation' });
    }
  });

  app.post('/api/tables/:tableName', async (req, res) => {
    try {
      await insertTableRow(req.params.tableName, req.body ?? {});
      res.status(201).json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Insert constraint error' });
    }
  });

  app.put('/api/tables/:tableName/:pk', async (req, res) => {
    try {
      await updateTableRow(req.params.tableName, req.params.pk, req.body ?? {});
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Update constraint error' });
    }
  });

  app.delete('/api/tables/:tableName/:pk', async (req, res) => {
    try {
      await deleteTableRow(req.params.tableName, req.params.pk);
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Delete constraint error' });
    }
  });

  app.post('/api/students/composite', async (req, res) => {
    try {
      const result = await createStudentWithHabits(req.body);
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Transaction failed' });
    }
  });

  app.put('/api/students/:id/habits', async (req, res) => {
    try {
      const studentId = Number(req.params.id);
      if (!Number.isFinite(studentId)) {
        res.status(400).json({ error: 'Invalid student_id' });
        return;
      }
      await updateStudentHabits(studentId, req.body);
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Habit update failed' });
    }
  });

  app.post('/api/reset', async (_req, res) => {
    try {
      await resetDatabase();
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Reset failed' });
    }
  });

  const FRONTEND_FILES = [
    { filePath: 'index.html', lang: 'html' },
    { filePath: 'vite.config.ts', lang: 'ts' },
    { filePath: 'tsconfig.json', lang: 'json' },
    { filePath: 'src/index.css', lang: 'css' },
    { filePath: 'src/main.tsx', lang: 'tsx' },
    { filePath: 'src/types/dbms.ts', lang: 'ts' },
    { filePath: 'src/App.tsx', lang: 'tsx' },
    { filePath: 'src/components/PerformanceDashboard.tsx', lang: 'tsx' },
    { filePath: 'src/components/SchemaExplorer.tsx', lang: 'tsx' },
    { filePath: 'src/components/SqlConsole.tsx', lang: 'tsx' },
    { filePath: 'src/components/TableBrowser.tsx', lang: 'tsx' },
    { filePath: 'src/components/FactorSimulator.tsx', lang: 'tsx' },
    { filePath: 'src/components/AddStudentModal.tsx', lang: 'tsx' },
  ];

  const BACKEND_FILES = [
    { filePath: 'package.json', lang: 'json' },
    { filePath: 'src/types/dbms.ts', lang: 'ts' },
    { filePath: 'server.ts', lang: 'ts' },
    { filePath: 'server/db.ts', lang: 'ts' },
    { filePath: 'server/pdf.ts', lang: 'ts' },
  ];

  const FULL_FILES = [
    { filePath: 'package.json', lang: 'json' },
    { filePath: 'metadata.json', lang: 'json' },
    { filePath: 'index.html', lang: 'html' },
    { filePath: 'vite.config.ts', lang: 'ts' },
    { filePath: 'tsconfig.json', lang: 'json' },
    { filePath: 'src/types/dbms.ts', lang: 'ts' },
    { filePath: 'server.ts', lang: 'ts' },
    { filePath: 'server/db.ts', lang: 'ts' },
    { filePath: 'server/pdf.ts', lang: 'ts' },
    { filePath: 'src/index.css', lang: 'css' },
    { filePath: 'src/main.tsx', lang: 'tsx' },
    { filePath: 'src/App.tsx', lang: 'tsx' },
    { filePath: 'src/components/PerformanceDashboard.tsx', lang: 'tsx' },
    { filePath: 'src/components/SchemaExplorer.tsx', lang: 'tsx' },
    { filePath: 'src/components/SqlConsole.tsx', lang: 'tsx' },
    { filePath: 'src/components/TableBrowser.tsx', lang: 'tsx' },
    { filePath: 'src/components/FactorSimulator.tsx', lang: 'tsx' },
    { filePath: 'src/components/AddStudentModal.tsx', lang: 'tsx' },
  ];

  function createZipBuffer(fileEntries: Array<{ filePath: string }>): Buffer {
    const localParts: Buffer[] = [];
    const centralParts: Buffer[] = [];
    let offset = 0;
    let entryCount = 0;

    for (const entry of fileEntries) {
      const absPath = path.resolve(process.cwd(), entry.filePath);
      if (!fs.existsSync(absPath)) continue;
      entryCount++;
      const raw = fs.readFileSync(absPath);
      const compressed = zlib.deflateRawSync(raw);
      const crc = zlib.crc32(raw) >>> 0;
      const nameBuf = Buffer.from(entry.filePath, 'utf8');

      const localHeader = Buffer.alloc(30);
      localHeader.writeUInt32LE(0x04034b50, 0); // Local file header signature
      localHeader.writeUInt16LE(20, 4); // Version needed
      localHeader.writeUInt16LE(0x0800, 6); // UTF-8 flag
      localHeader.writeUInt16LE(8, 8); // Compression method: DEFLATE
      localHeader.writeUInt16LE(0, 10); // Mod time
      localHeader.writeUInt16LE(0x5421, 12); // Mod date
      localHeader.writeUInt32LE(crc, 14);
      localHeader.writeUInt32LE(compressed.length, 18);
      localHeader.writeUInt32LE(raw.length, 22);
      localHeader.writeUInt16LE(nameBuf.length, 26);
      localHeader.writeUInt16LE(0, 28); // Extra field length

      localParts.push(localHeader, nameBuf, compressed);

      const centralHeader = Buffer.alloc(46);
      centralHeader.writeUInt32LE(0x02014b50, 0); // Central directory signature
      centralHeader.writeUInt16LE(20, 4); // Version made by
      centralHeader.writeUInt16LE(20, 6); // Version needed
      centralHeader.writeUInt16LE(0x0800, 8); // UTF-8 flag
      centralHeader.writeUInt16LE(8, 10); // DEFLATE
      centralHeader.writeUInt16LE(0, 12);
      centralHeader.writeUInt16LE(0x5421, 14);
      centralHeader.writeUInt32LE(crc, 16);
      centralHeader.writeUInt32LE(compressed.length, 20);
      centralHeader.writeUInt32LE(raw.length, 24);
      centralHeader.writeUInt16LE(nameBuf.length, 28);
      centralHeader.writeUInt16LE(0, 30);
      centralHeader.writeUInt16LE(0, 32);
      centralHeader.writeUInt16LE(0, 34);
      centralHeader.writeUInt16LE(0, 36);
      centralHeader.writeUInt32LE(0, 38);
      centralHeader.writeUInt32LE(offset, 42);

      centralParts.push(centralHeader, nameBuf);
      offset += localHeader.length + nameBuf.length + compressed.length;
    }

    const centralDirBuf = Buffer.concat(centralParts);
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(0, 4);
    eocd.writeUInt16LE(0, 6);
    eocd.writeUInt16LE(entryCount, 8);
    eocd.writeUInt16LE(entryCount, 10);
    eocd.writeUInt32LE(centralDirBuf.length, 12);
    eocd.writeUInt32LE(offset, 16);
    eocd.writeUInt16LE(0, 20);

    return Buffer.concat([...localParts, centralDirBuf, eocd]);
  }

  app.get('/api/download-zip/:part', (req, res) => {
    const part = req.params.part;
    const map: Record<string, { filename: string; files: Array<{ filePath: string }> }> = {
      frontend: { filename: 'ScholarDB_Frontend_Source.zip', files: FRONTEND_FILES },
      backend: { filename: 'ScholarDB_Backend_Source.zip', files: BACKEND_FILES },
      full: { filename: 'ScholarDB_Full_Project.zip', files: FULL_FILES },
    };
    const cfg = map[part];
    if (!cfg) {
      res.status(404).json({ error: 'Unknown archive bundle requested' });
      return;
    }
    const zipBuf = createZipBuffer(cfg.files);
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${cfg.filename}"`);
    res.send(zipBuf);
  });

  app.get('/api/download-code/:part', (req, res) => {
    const part = req.params.part;
    const bundleConfigs: Record<
      string,
      {
        filename: string;
        title: string;
        files: Array<{ filePath: string; lang: string }>;
      }
    > = {
      backend: {
        filename: 'ScholarDB_Backend_Code.md',
        title: 'ScholarDB — Backend Code (Express + SQLite DBMS Engine)',
        files: BACKEND_FILES,
      },
      frontend: {
        filename: 'ScholarDB_Frontend_Code.md',
        title: 'ScholarDB — Frontend Code (React + TypeScript + Tailwind CSS)',
        files: FRONTEND_FILES,
      },
      full: {
        filename: 'ScholarDB_Full_Source_Code.md',
        title: 'ScholarDB — Complete Frontend & Backend Source Code',
        files: FULL_FILES,
      },
    };

    const config = bundleConfigs[part];
    if (!config) {
      res.status(404).json({ error: 'Unknown code bundle requested' });
      return;
    }

    const lines: string[] = [
      `# ${config.title}`,
      '',
      'Presented by: RICHARD BENSON RAJ.B.A · AJAY.B · S.MOHAMED ASFARALI',
      '',
      '## Included Files',
      ...config.files.map((f, idx) => `${idx + 1}. \`${f.filePath}\``),
      '',
    ];

    for (const f of config.files) {
      const absPath = path.resolve(process.cwd(), f.filePath);
      if (!fs.existsSync(absPath)) continue;
      const content = fs.readFileSync(absPath, 'utf8').replace(/\n$/, '');
      lines.push('---', '', `## \`${f.filePath}\``, '', `\`\`\`${f.lang}`, content, '```', '');
    }

    const payload = lines.join('\n');
    res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${config.filename}"`);
    res.send(payload);
  });

  app.get('/api/download-pdf', async (_req, res) => {
    try {
      const pdfBuffer = await generateProjectPdfBuffer();
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="ScholarDB_DBMS_Project_Report.pdf"'
      );
      res.send(pdfBuffer);
    } catch (err) {
      res
        .status(500)
        .json({ error: err instanceof Error ? err.message : 'PDF generation failed' });
    }
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`ScholarDB server listening on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start ScholarDB server:', err);
  process.exit(1);
});
