import { useState } from 'react';
import { X } from 'lucide-react';
import type { Department } from '../types/dbms';

interface AddStudentModalProps {
  departments: Department[];
  onClose: () => void;
  onCreated: () => void;
}

export function AddStudentModal({ departments, onClose, onCreated }: AddStudentModalProps) {
  const [rollNo, setRollNo] = useState(`CS26-${Math.floor(200 + Math.random() * 700)}`);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [deptId, setDeptId] = useState<number>(departments[0]?.dept_id ?? 1);
  const [semester, setSemester] = useState<number>(4);
  const [priorGpa, setPriorGpa] = useState<number>(3.4);
  const [weeklyStudyHours, setWeeklyStudyHours] = useState<number>(22);
  const [sleepHours, setSleepHours] = useState<number>(7.2);
  const [attendancePct, setAttendancePct] = useState<number>(88);
  const [preferredMode, setPreferredMode] = useState<'Solo' | 'Study Group' | 'Hybrid'>('Hybrid');
  const [distractionHours, setDistractionHours] = useState<number>(1.8);
  const [courseId, setCourseId] = useState<number>(1);
  const [midtermScore, setMidtermScore] = useState<number>(82);
  const [assignmentScore, setAssignmentScore] = useState<number>(88);
  const [practiceTests, setPracticeTests] = useState<number>(5);
  const [finalScore, setFinalScore] = useState<number>(85);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch('/api/students/composite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roll_no: rollNo.trim(),
          full_name: fullName.trim(),
          email: email.trim(),
          dept_id: deptId,
          enrollment_year: 2026,
          semester,
          prior_gpa: priorGpa,
          extracurricular_hours: 4,
          commute_minutes: 25,
          weekly_study_hours: weeklyStudyHours,
          sleep_hours_avg: sleepHours,
          attendance_pct: attendancePct,
          preferred_mode: preferredMode,
          distraction_hours_daily: distractionHours,
          tutoring_sessions_month: 2,
          internet_access_quality: 'High',
          course_id: courseId,
          midterm_score: midtermScore,
          assignment_score: assignmentScore,
          practice_tests_completed: practiceTests,
          final_score: finalScore,
        }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? 'Transaction rolled back due to SQLite constraint violation.');
        return;
      }
      onCreated();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4">
      <div className="w-full max-w-2xl rounded-lg border border-slate-200 bg-white shadow-lg">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Enroll Student (Atomic Multi-Table Transaction)
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Inserts into <span className="font-mono">students</span>,{' '}
              <span className="font-mono">study_habits</span>, and{' '}
              <span className="font-mono">enrollments</span> with SQLite trigger grade calculation
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={(e) => void handleSubmit(e)} className="p-5 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="rounded-md border border-red-200 bg-red-50 p-3 font-mono text-xs text-red-800">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Roll No *</label>
              <input
                required
                value={rollNo}
                onChange={(e) => setRollNo(e.target.value)}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Full Name *</label>
              <input
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Riya Kulkarni"
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Academic Email *</label>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="riya.k@scholardb.edu"
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-4 border-t border-slate-100 pt-4">
            <div className="space-y-1 sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700">Department</label>
              <select
                value={deptId}
                onChange={(e) => setDeptId(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 bg-white px-2.5 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              >
                {departments.map((d) => (
                  <option key={d.dept_id} value={d.dept_id}>
                    {d.dept_code} — {d.dept_name}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Semester (1–8)</label>
              <input
                type="number"
                min={1}
                max={8}
                value={semester}
                onChange={(e) => setSemester(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Prior GPA (0–4)</label>
              <input
                type="number"
                step="0.01"
                min={0}
                max={4}
                value={priorGpa}
                onChange={(e) => setPriorGpa(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-5 border-t border-slate-100 pt-4">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Study hrs/wk</label>
              <input
                type="number"
                step="0.5"
                value={weeklyStudyHours}
                onChange={(e) => setWeeklyStudyHours(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Attendance %</label>
              <input
                type="number"
                step="0.5"
                value={attendancePct}
                onChange={(e) => setAttendancePct(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Sleep hrs</label>
              <input
                type="number"
                step="0.1"
                value={sleepHours}
                onChange={(e) => setSleepHours(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Distraction hrs</label>
              <input
                type="number"
                step="0.1"
                value={distractionHours}
                onChange={(e) => setDistractionHours(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Study Mode</label>
              <select
                value={preferredMode}
                onChange={(e) => setPreferredMode(e.target.value as 'Solo' | 'Study Group' | 'Hybrid')}
                className="h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              >
                <option value="Solo">Solo</option>
                <option value="Study Group">Study Group</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-5 border-t border-slate-100 pt-4">
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Course ID</label>
              <input
                type="number"
                min={1}
                max={12}
                value={courseId}
                onChange={(e) => setCourseId(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Midterm Score</label>
              <input
                type="number"
                step="0.5"
                value={midtermScore}
                onChange={(e) => setMidtermScore(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Assignment</label>
              <input
                type="number"
                step="0.5"
                value={assignmentScore}
                onChange={(e) => setAssignmentScore(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Practice Tests</label>
              <input
                type="number"
                value={practiceTests}
                onChange={(e) => setPracticeTests(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">Final Score</label>
              <input
                type="number"
                step="0.5"
                value={finalScore}
                onChange={(e) => setFinalScore(Number(e.target.value))}
                className="h-9 w-full rounded-md border border-slate-200 px-2.5 font-mono text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-md bg-blue-700 px-4 py-2 text-xs font-medium text-white hover:bg-blue-800 disabled:opacity-50"
            >
              {submitting ? 'Committing Transaction...' : 'Commit Student Transaction'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
