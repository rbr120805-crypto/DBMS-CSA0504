import { useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import type { SchemaMetadataPayload, TableRowsPayload } from '../types/dbms';

interface TableBrowserProps {
  schema: SchemaMetadataPayload | null;
  selectedTable: string;
  onSelectTable: (name: string) => void;
  onMutated: () => void;
}

const ENUM_SUGGESTIONS: Record<string, string[]> = {
  difficulty_level: ['Core', 'Elective', 'Honors'],
  preferred_mode: ['Solo', 'Study Group', 'Hybrid'],
  internet_access_quality: ['High', 'Moderate', 'Limited'],
  session_type: ['Deep Work', 'Revision', 'Lab Practice', 'Group Review'],
  grade_letter: ['A', 'A-', 'B+', 'B', 'C+', 'C', 'D', 'F'],
};

export function TableBrowser({
  schema,
  selectedTable,
  onSelectTable,
  onMutated,
}: TableBrowserProps) {
  const [tableData, setTableData] = useState<TableRowsPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [modalMode, setModalMode] = useState<'insert' | 'edit' | null>(null);
  const [formState, setFormState] = useState<Record<string, string>>({});
  const [editingPk, setEditingPk] = useState<string | number | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const loadTable = async (name: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/tables/${encodeURIComponent(name)}`);
      const data = (await res.json()) as TableRowsPayload;
      if (res.ok) {
        setTableData(data);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadTable(selectedTable);
    setSearchTerm('');
  }, [selectedTable]);

  const filteredRows = useMemo(() => {
    if (!tableData) return [];
    const q = searchTerm.trim().toLowerCase();
    if (!q) return tableData.rows;
    return tableData.rows.filter((row) =>
      Object.values(row).some((val) => String(val ?? '').toLowerCase().includes(q))
    );
  }, [tableData, searchTerm]);

  const pkCol = tableData?.columns.find((c) => c.pk === 1)?.name;

  const openInsertModal = () => {
    if (!tableData) return;
    const init: Record<string, string> = {};
    for (const col of tableData.columns) {
      if (col.pk === 1) continue;
      const fkOpts = tableData.lookupOptions[col.name];
      if (fkOpts && fkOpts.length > 0) {
        init[col.name] = String(fkOpts[0].value);
      } else if (ENUM_SUGGESTIONS[col.name]) {
        init[col.name] = ENUM_SUGGESTIONS[col.name][0];
      } else if (col.dflt_value !== null) {
        init[col.name] = col.dflt_value.replace(/^'|'$/g, '');
      } else {
        init[col.name] = '';
      }
    }
    setFormState(init);
    setEditingPk(null);
    setFormError(null);
    setModalMode('insert');
  };

  const openEditModal = (row: Record<string, unknown>) => {
    if (!tableData || !pkCol) return;
    const init: Record<string, string> = {};
    for (const col of tableData.columns) {
      if (col.pk === 1) continue;
      init[col.name] = row[col.name] === null || row[col.name] === undefined ? '' : String(row[col.name]);
    }
    setFormState(init);
    setEditingPk(row[pkCol] as string | number);
    setFormError(null);
    setModalMode('edit');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tableData) return;
    setSubmitting(true);
    setFormError(null);

    const payload: Record<string, unknown> = {};
    for (const col of tableData.columns) {
      if (col.pk === 1) continue;
      const raw = formState[col.name] ?? '';
      if (raw === '') {
        payload[col.name] = null;
      } else if (col.type.toUpperCase().includes('INT') || col.type.toUpperCase().includes('REAL')) {
        const num = Number(raw);
        payload[col.name] = Number.isNaN(num) ? raw : num;
      } else {
        payload[col.name] = raw;
      }
    }

    try {
      const url =
        modalMode === 'edit' && editingPk !== null
          ? `/api/tables/${encodeURIComponent(tableData.tableName)}/${encodeURIComponent(String(editingPk))}`
          : `/api/tables/${encodeURIComponent(tableData.tableName)}`;
      const res = await fetch(url, {
        method: modalMode === 'edit' ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok) {
        setFormError(json.error ?? 'SQLite rejected this operation.');
        return;
      }
      setModalMode(null);
      await loadTable(tableData.tableName);
      onMutated();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Request failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (pkVal: unknown) => {
    if (!tableData || pkVal === undefined || pkVal === null) return;
    try {
      const res = await fetch(
        `/api/tables/${encodeURIComponent(tableData.tableName)}/${encodeURIComponent(String(pkVal))}`,
        { method: 'DELETE' }
      );
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setFormError(json.error ?? 'Cannot delete record due to FOREIGN KEY constraint.');
        return;
      }
      setFormError(null);
      await loadTable(tableData.tableName);
      onMutated();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  const tablesList = schema?.tables ?? [];

  return (
    <div className="space-y-6">
      {/* Relation Switcher */}
      <div className="rounded-lg border border-slate-200 bg-white p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-1.5">
            {tablesList.map((t) => (
              <button
                key={t.name}
                type="button"
                onClick={() => onSelectTable(t.name)}
                className={`px-3 py-1.5 rounded-md font-mono text-xs transition-colors whitespace-nowrap shrink-0 ${
                  selectedTable === t.name
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {t.name}
                <span className="ml-1.5 opacity-70 tabular-nums">({t.rowCount})</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {formError && !modalMode && (
        <div className="flex items-center justify-between rounded-md border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">
          <span className="font-mono">{formError}</span>
          <button type="button" onClick={() => setFormError(null)} className="text-red-600 hover:text-red-900">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Data Grid */}
      <div className="rounded-lg border border-slate-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-5 py-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-mono text-base font-semibold text-slate-900">{selectedTable}</h2>
              <span className="text-xs text-slate-500">
                {tableData?.kind === 'view' ? 'Read-only SQL View' : 'Base Table · Live CRUD'}
              </span>
            </div>
            <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
              Showing {filteredRows.length} of {tableData?.totalCount ?? 0} total tuples
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Filter rows..."
                className="h-8 w-48 rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>

            {tableData?.kind === 'table' && (
              <button
                type="button"
                onClick={openInsertModal}
                className="inline-flex items-center gap-1.5 rounded-md bg-blue-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-800 whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" />
                Insert Row
              </button>
            )}
          </div>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500">Loading relation tuples...</div>
        ) : !tableData || filteredRows.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">No rows found in {selectedTable}.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                  {tableData.columns.map((col) => (
                    <th key={col.name} className="px-4 py-2.5 font-mono font-semibold whitespace-nowrap">
                      {col.name}
                      {col.pk === 1 && <span className="ml-1 text-[10px] text-amber-600">PK</span>}
                    </th>
                  ))}
                  {tableData.kind === 'table' && pkCol && (
                    <th className="px-4 py-2.5 text-right font-medium whitespace-nowrap">Actions</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 tabular-nums">
                {filteredRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    {tableData.columns.map((col) => {
                      const val = row[col.name];
                      return (
                        <td
                          key={col.name}
                          className={`px-4 py-2 whitespace-nowrap ${
                            typeof val === 'number' ? 'font-mono text-slate-800' : 'text-slate-700'
                          }`}
                        >
                          {val === null || val === undefined ? (
                            <span className="font-mono text-slate-400">NULL</span>
                          ) : (
                            String(val)
                          )}
                        </td>
                      );
                    })}
                    {tableData.kind === 'table' && pkCol && (
                      <td className="px-4 py-2 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => openEditModal(row)}
                            title="Edit row"
                            className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleDelete(row[pkCol])}
                            title="Delete row"
                            className="rounded p-1 text-slate-500 hover:bg-red-50 hover:text-red-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Insert / Edit Modal */}
      {modalMode && tableData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-lg rounded-lg border border-slate-200 bg-white shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  {modalMode === 'insert' ? `Insert into ${tableData.tableName}` : `Update ${tableData.tableName}`}
                </h3>
                <p className="text-xs text-slate-500">
                  All SQLite CHECK, UNIQUE, and FOREIGN KEY constraints are enforced
                </p>
              </div>
              <button
                type="button"
                onClick={() => setModalMode(null)}
                className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={(e) => void handleSubmit(e)} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
              {formError && (
                <div className="rounded-md border border-red-200 bg-red-50 p-3 font-mono text-xs text-red-800">
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {tableData.columns
                  .filter((col) => col.pk !== 1)
                  .map((col) => {
                    const fkOpts = tableData.lookupOptions[col.name];
                    const enumOpts = ENUM_SUGGESTIONS[col.name];
                    return (
                      <div key={col.name} className="space-y-1">
                        <label className="block font-mono text-[11px] font-medium text-slate-700">
                          {col.name}
                          {col.notnull === 1 && <span className="text-red-500 ml-0.5">*</span>}
                        </label>
                        {fkOpts ? (
                          <select
                            value={formState[col.name] ?? ''}
                            onChange={(e) =>
                              setFormState((prev) => ({ ...prev, [col.name]: e.target.value }))
                            }
                            className="h-9 w-full rounded-md border border-slate-200 bg-white px-2.5 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
                          >
                            {fkOpts.map((opt) => (
                              <option key={opt.value} value={opt.value}>
                                {opt.label}
                              </option>
                            ))}
                          </select>
                        ) : enumOpts ? (
                          <select
                            value={formState[col.name] ?? ''}
                            onChange={(e) =>
                              setFormState((prev) => ({ ...prev, [col.name]: e.target.value }))
                            }
                            className="h-9 w-full rounded-md border border-slate-200 bg-white px-2.5 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
                          >
                            {enumOpts.map((opt) => (
                              <option key={opt} value={opt}>
                                {opt}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <input
                            type={
                              col.type.toUpperCase().includes('INT') ||
                              col.type.toUpperCase().includes('REAL')
                                ? 'number'
                                : 'text'
                            }
                            step="any"
                            value={formState[col.name] ?? ''}
                            onChange={(e) =>
                              setFormState((prev) => ({ ...prev, [col.name]: e.target.value }))
                            }
                            className="h-9 w-full rounded-md border border-slate-200 bg-white px-2.5 text-xs text-slate-900 focus:border-blue-600 focus:outline-none"
                          />
                        )}
                      </div>
                    );
                  })}
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={() => setModalMode(null)}
                  className="rounded-md border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="rounded-md bg-blue-700 px-4 py-2 text-xs font-medium text-white hover:bg-blue-800 disabled:opacity-50"
                >
                  {submitting ? 'Saving...' : modalMode === 'insert' ? 'Insert Tuple' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
