import { useEffect, useState } from 'react';
import { Check, RotateCcw, Save } from 'lucide-react';
import type { AnalyticsPayload } from '../types/dbms';

interface FactorSimulatorProps {
  analytics: AnalyticsPayload | null;
  selectedStudentId: number | null;
  onSelectStudentId: (id: number) => void;
  onCommitted: () => void;
}

function getLetterGrade(score: number): string {
  if (score >= 90) return 'A';
  if (score >= 85) return 'A-';
  if (score >= 80) return 'B+';
  if (score >= 75) return 'B';
  if (score >= 70) return 'C+';
  if (score >= 60) return 'C';
  if (score >= 50) return 'D';
  return 'F';
}

export function FactorSimulator({
  analytics,
  selectedStudentId,
  onSelectStudentId,
  onCommitted,
}: FactorSimulatorProps) {
  const students = analytics?.students ?? [];
  const activeStudent =
    students.find((s) => s.student_id === selectedStudentId) ?? students[0] ?? null;

  const [studyHours, setStudyHours] = useState<number>(18);
  const [attendance, setAttendance] = useState<number>(85);
  const [sleepHours, setSleepHours] = useState<number>(7.0);
  const [distractionHours, setDistractionHours] = useState<number>(2.5);
  const [practiceTests, setPracticeTests] = useState<number>(4);
  const [preferredMode, setPreferredMode] = useState<'Solo' | 'Study Group' | 'Hybrid'>('Hybrid');
  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    if (!activeStudent) return;
    setStudyHours(activeStudent.weekly_study_hours);
    setAttendance(activeStudent.attendance_pct);
    setSleepHours(activeStudent.sleep_hours_avg);
    setDistractionHours(activeStudent.distraction_hours_daily);
    const perCourse =
      activeStudent.courses_enrolled > 0
        ? Math.round((activeStudent.total_practice_tests / activeStudent.courses_enrolled) * 10) / 10
        : 3;
    setPracticeTests(perCourse);
    setPreferredMode(activeStudent.preferred_mode);
    setSavedNotice(false);
  }, [activeStudent?.student_id]);

  if (!analytics || !activeStudent) {
    return (
      <div className="rounded-lg border border-slate-200 bg-white p-8 text-center text-xs text-slate-500">
        No student profiles available for simulation.
      </div>
    );
  }

  const model = analytics.regressionModel;
  const w = model.weights;

  const rawPredicted =
    model.intercept +
    w.weekly_study_hours * studyHours +
    w.attendance_pct * attendance +
    w.sleep_hours_avg * sleepHours +
    w.distraction_hours_daily * distractionHours +
    w.practice_tests_per_course * practiceTests +
    w.prior_gpa * activeStudent.prior_gpa;

  const predictedScore = Math.max(0, Math.min(100, Number(rawPredicted.toFixed(1))));
  const delta = Number((predictedScore - activeStudent.avg_final_score).toFixed(1));
  const projectedGrade = getLetterGrade(predictedScore);

  const handleReset = () => {
    setStudyHours(activeStudent.weekly_study_hours);
    setAttendance(activeStudent.attendance_pct);
    setSleepHours(activeStudent.sleep_hours_avg);
    setDistractionHours(activeStudent.distraction_hours_daily);
    const perCourse =
      activeStudent.courses_enrolled > 0
        ? Math.round((activeStudent.total_practice_tests / activeStudent.courses_enrolled) * 10) / 10
        : 3;
    setPracticeTests(perCourse);
    setPreferredMode(activeStudent.preferred_mode);
  };

  const handleCommitHabits = async () => {
    setSaving(true);
    setSavedNotice(false);
    try {
      const res = await fetch(`/api/students/${activeStudent.student_id}/habits`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          weekly_study_hours: studyHours,
          sleep_hours_avg: sleepHours,
          attendance_pct: attendance,
          distraction_hours_daily: distractionHours,
          preferred_mode: preferredMode,
        }),
      });
      if (res.ok) {
        setSavedNotice(true);
        onCommitted();
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Controls Column */}
        <div className="lg:col-span-7 rounded-lg border border-slate-200 bg-white p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Study Habit What-If Simulator
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Modify study factors and commit updated tuples directly to <span className="font-mono">study_habits</span>
              </p>
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset to Stored
            </button>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-700">Target Student Record</label>
            <select
              value={activeStudent.student_id}
              onChange={(e) => onSelectStudentId(Number(e.target.value))}
              className="h-9 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
            >
              {students.map((s) => (
                <option key={s.student_id} value={s.student_id}>
                  {s.roll_no} — {s.full_name} ({s.dept_code}, Current: {s.avg_final_score}%)
                </option>
              ))}
            </select>
          </div>

          {/* Sliders */}
          <div className="space-y-4 pt-1">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Weekly Study Hours</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {studyHours.toFixed(1)} hrs/wk
                </span>
              </div>
              <input
                type="range"
                min={2}
                max={45}
                step={0.5}
                value={studyHours}
                onChange={(e) => setStudyHours(Number(e.target.value))}
                className="w-full accent-blue-700"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Lecture Attendance</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {attendance.toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min={40}
                max={100}
                step={0.5}
                value={attendance}
                onChange={(e) => setAttendance(Number(e.target.value))}
                className="w-full accent-blue-700"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Average Nightly Sleep</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {sleepHours.toFixed(1)} hrs/night
                </span>
              </div>
              <input
                type="range"
                min={4}
                max={10}
                step={0.1}
                value={sleepHours}
                onChange={(e) => setSleepHours(Number(e.target.value))}
                className="w-full accent-blue-700"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Daily Screen Distraction</span>
                <span className="font-mono font-semibold text-red-600 tabular-nums">
                  {distractionHours.toFixed(1)} hrs/day
                </span>
              </div>
              <input
                type="range"
                min={0.5}
                max={8}
                step={0.1}
                value={distractionHours}
                onChange={(e) => setDistractionHours(Number(e.target.value))}
                className="w-full accent-red-600"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Practice Tests per Course</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {practiceTests.toFixed(1)} tests
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={12}
                step={0.5}
                value={practiceTests}
                onChange={(e) => setPracticeTests(Number(e.target.value))}
                className="w-full accent-blue-700"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-medium text-slate-700">Preferred Study Mode</span>
              <div className="flex items-center gap-1 rounded-md bg-slate-100 p-1">
                {(['Solo', 'Study Group', 'Hybrid'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setPreferredMode(m)}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                      preferredMode === m
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <span className="text-xs text-slate-500">
              {savedNotice ? (
                <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                  <Check className="h-3.5 w-3.5" />
                  Updated study_habits row in SQLite
                </span>
              ) : (
                'Saves directly to study_habits table via SQL UPDATE'
              )}
            </span>
            <button
              type="button"
              disabled={saving}
              onClick={() => void handleCommitHabits()}
              className="inline-flex items-center gap-1.5 rounded-md bg-blue-700 px-4 py-2 text-xs font-medium text-white hover:bg-blue-800 disabled:opacity-50 whitespace-nowrap"
            >
              <Save className="h-3.5 w-3.5" />
              {saving ? 'Committing...' : 'Commit Habits to Database'}
            </button>
          </div>
        </div>

        {/* Prediction & Regression Breakdown */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-lg border border-slate-200 bg-white p-5">
            <p className="text-xs font-medium text-slate-500">Projected Final Score (OLS Model)</p>
            <div className="mt-3 flex items-baseline justify-between border-b border-slate-100 pb-4">
              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-semibold tracking-tight text-slate-900 tabular-nums">
                  {predictedScore.toFixed(1)}%
                </span>
                <span className="font-mono text-lg font-semibold text-blue-700">
                  Grade {projectedGrade}
                </span>
              </div>
              <span
                className={`font-mono text-xs font-semibold tabular-nums ${
                  delta > 0 ? 'text-emerald-700' : delta < 0 ? 'text-red-600' : 'text-slate-500'
                }`}
              >
                {delta >= 0 ? `+${delta.toFixed(1)}%` : `${delta.toFixed(1)}%`} vs actual ({activeStudent.avg_final_score}%)
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 text-xs tabular-nums">
              <div className="rounded-md bg-slate-50 p-3">
                <span className="text-slate-500">Model R² Fit</span>
                <p className="mt-1 font-mono text-sm font-semibold text-slate-900">
                  {model.rSquared.toFixed(3)}
                </p>
              </div>
              <div className="rounded-md bg-slate-50 p-3">
                <span className="text-slate-500">Residual RMSE</span>
                <p className="mt-1 font-mono text-sm font-semibold text-slate-900">
                  ±{model.rmse.toFixed(2)} pts
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-5">
            <h3 className="text-sm font-semibold text-slate-900">
              Fitted Multiple Regression Coefficients
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Computed server-side via normal equations on {analytics.students.length} database tuples
            </p>
            <div className="mt-4 divide-y divide-slate-100 text-xs tabular-nums">
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Intercept (β₀)</span>
                <span className="font-mono font-medium text-slate-900">{model.intercept}</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Weekly Study Hours (β₁)</span>
                <span className="font-mono font-medium text-blue-700">+{w.weekly_study_hours} / hr</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Attendance % (β₂)</span>
                <span className="font-mono font-medium text-blue-700">+{w.attendance_pct} / %</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Nightly Sleep (β₃)</span>
                <span className="font-mono font-medium text-blue-700">+{w.sleep_hours_avg} / hr</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Daily Distraction (β₄)</span>
                <span className="font-mono font-medium text-red-600">{w.distraction_hours_daily} / hr</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Practice Tests (β₅)</span>
                <span className="font-mono font-medium text-blue-700">+{w.practice_tests_per_course} / test</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-600">Prior GPA (β₆)</span>
                <span className="font-mono font-medium text-blue-700">+{w.prior_gpa} / pt</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
