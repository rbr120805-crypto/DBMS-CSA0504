import { useMemo, useState } from 'react';
import { ArrowUpDown, Search, SlidersHorizontal } from 'lucide-react';
import type { AnalyticsPayload, StudentPerformanceRow } from '../types/dbms';

interface PerformanceDashboardProps {
  analytics: AnalyticsPayload | null;
  loading: boolean;
  deptFilter: string;
  modeFilter: string;
  onDeptFilterChange: (dept: string) => void;
  onModeFilterChange: (mode: string) => void;
  onSimulateStudent: (studentId: number) => void;
}

type ScatterFactorKey =
  | 'weekly_study_hours'
  | 'attendance_pct'
  | 'sleep_hours_avg'
  | 'distraction_hours_daily'
  | 'total_practice_tests';

const SCATTER_FACTORS: Array<{
  key: ScatterFactorKey;
  label: string;
  unit: string;
  min: number;
  max: number;
}> = [
  { key: 'weekly_study_hours', label: 'Weekly Study Hours', unit: 'hrs/wk', min: 0, max: 45 },
  { key: 'attendance_pct', label: 'Lecture Attendance', unit: '%', min: 45, max: 100 },
  { key: 'sleep_hours_avg', label: 'Nightly Sleep', unit: 'hrs', min: 4, max: 9.5 },
  { key: 'distraction_hours_daily', label: 'Daily Distraction', unit: 'hrs/day', min: 0, max: 8 },
  { key: 'total_practice_tests', label: 'Practice Tests', unit: 'tests', min: 0, max: 35 },
];

const DEPT_COLORS: Record<string, string> = {
  CS: '#1d4ed8',
  DS: '#0f766e',
  MATH: '#7c3aed',
  ECE: '#d97706',
};

export function PerformanceDashboard({
  analytics,
  loading,
  deptFilter,
  modeFilter,
  onDeptFilterChange,
  onModeFilterChange,
  onSimulateStudent,
}: PerformanceDashboardProps) {
  const [selectedFactor, setSelectedFactor] = useState<ScatterFactorKey>('weekly_study_hours');
  const [hoveredStudent, setHoveredStudent] = useState<StudentPerformanceRow | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<'ALL' | 'At Risk' | 'Watch' | 'Nominal'>('ALL');
  const [sortCol, setSortCol] = useState<'avg_final_score' | 'weekly_study_hours' | 'attendance_pct' | 'distraction_hours_daily'>('avg_final_score');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const factorConfig = SCATTER_FACTORS.find((f) => f.key === selectedFactor) ?? SCATTER_FACTORS[0];

  const scatterStats = useMemo(() => {
    const rows = analytics?.students ?? [];
    if (rows.length < 2) return { slope: 0, intercept: 0, r: 0 };
    const xs = rows.map((s) => Number(s[selectedFactor]));
    const ys = rows.map((s) => s.avg_final_score);
    const n = xs.length;
    const meanX = xs.reduce((a, b) => a + b, 0) / n;
    const meanY = ys.reduce((a, b) => a + b, 0) / n;
    let num = 0;
    let denX = 0;
    let denY = 0;
    for (let i = 0; i < n; i++) {
      const dx = xs[i] - meanX;
      const dy = ys[i] - meanY;
      num += dx * dy;
      denX += dx * dx;
      denY += dy * dy;
    }
    const slope = denX > 0 ? num / denX : 0;
    const intercept = meanY - slope * meanX;
    const r = denX > 0 && denY > 0 ? num / Math.sqrt(denX * denY) : 0;
    return { slope, intercept, r };
  }, [analytics?.students, selectedFactor]);

  const filteredStudents = useMemo(() => {
    const rows = analytics?.students ?? [];
    const q = searchTerm.trim().toLowerCase();
    return rows
      .filter((s) => {
        if (riskFilter !== 'ALL' && s.risk_status !== riskFilter) return false;
        if (!q) return true;
        return (
          s.full_name.toLowerCase().includes(q) ||
          s.roll_no.toLowerCase().includes(q) ||
          s.dept_code.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        const av = a[sortCol];
        const bv = b[sortCol];
        return sortDir === 'asc' ? av - bv : bv - av;
      });
  }, [analytics?.students, searchTerm, riskFilter, sortCol, sortDir]);

  const handleSort = (col: typeof sortCol) => {
    if (sortCol === col) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortCol(col);
      setSortDir('desc');
    }
  };

  if (loading && !analytics) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-24 rounded-lg border border-slate-200 bg-white p-4 animate-pulse" />
          ))}
        </div>
        <div className="h-96 rounded-lg border border-slate-200 bg-white animate-pulse" />
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="rounded-lg border border-slate-200 bg-white p-8 text-center">
        <p className="text-sm text-slate-600">No analytics records loaded.</p>
      </div>
    );
  }

  const svgW = 680;
  const svgH = 310;
  const padL = 48;
  const padR = 20;
  const padT = 18;
  const padB = 38;
  const plotW = svgW - padL - padR;
  const plotH = svgH - padT - padB;

  const xMin = factorConfig.min;
  const xMax = factorConfig.max;
  const yMin = 35;
  const yMax = 100;

  const toX = (val: number) => padL + ((Math.max(xMin, Math.min(xMax, val)) - xMin) / (xMax - xMin)) * plotW;
  const toY = (val: number) => padT + plotH - ((Math.max(yMin, Math.min(yMax, val)) - yMin) / (yMax - yMin)) * plotH;

  const lineX1 = xMin;
  const lineY1 = scatterStats.slope * lineX1 + scatterStats.intercept;
  const lineX2 = xMax;
  const lineY2 = scatterStats.slope * lineX2 + scatterStats.intercept;

  const maxBandCount = Math.max(1, ...analytics.gradeDistribution.map((g) => g.count));

  return (
    <div className="space-y-6">
      {/* Cohort Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-slate-200 bg-white px-4 py-3">
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 whitespace-nowrap shrink-0">
            <SlidersHorizontal className="h-3.5 w-3.5" />
            Department
          </span>
          <div className="flex flex-wrap items-center gap-1 rounded-md bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => onDeptFilterChange('ALL')}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                deptFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            {analytics.departments.map((d) => (
              <button
                key={d.dept_code}
                type="button"
                onClick={() => onDeptFilterChange(d.dept_code)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  deptFilter === d.dept_code
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {d.dept_code}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <span className="text-xs font-medium text-slate-500 whitespace-nowrap shrink-0">Study Mode</span>
          <div className="flex items-center gap-1 rounded-md bg-slate-100 p-1">
            {['ALL', 'Solo', 'Study Group', 'Hybrid'].map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => onModeFilterChange(mode)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  modeFilter === mode ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {mode === 'ALL' ? 'All Modes' : mode}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Filtered Cohort Size</p>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
              {analytics.kpis.totalStudents}
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              {analytics.kpis.totalEnrollments} enrollments
            </span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Mean Final Score</p>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
              {analytics.kpis.meanFinalScore.toFixed(1)}%
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              R² = {analytics.regressionModel.rSquared.toFixed(2)} model fit
            </span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Mean Weekly Study</p>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
              {analytics.kpis.meanStudyHours.toFixed(1)} hrs
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              {analytics.kpis.meanAttendance.toFixed(1)}% avg attendance
            </span>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">At-Risk Students</p>
          <div className="mt-2 flex items-baseline justify-between">
            <span
              className={`text-2xl font-semibold tracking-tight tabular-nums ${
                analytics.kpis.atRiskCount > 0 ? 'text-red-600' : 'text-emerald-600'
              }`}
            >
              {analytics.kpis.atRiskCount}
            </span>
            <span className="text-xs text-slate-500">Score &lt; 62% or Att &lt; 74%</span>
          </div>
        </div>
      </div>

      {/* Primary Charts Row: Scatter Plot + Factor Correlation Ranking */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        {/* Scatter Plot */}
        <div className="xl:col-span-7 rounded-lg border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Study Factor vs. Final Exam Score
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Live OLS trendline across {analytics.students.length} student records · Pearson r ={' '}
                <span className="font-mono font-medium text-slate-800 tabular-nums">
                  {scatterStats.r >= 0 ? `+${scatterStats.r.toFixed(3)}` : scatterStats.r.toFixed(3)}
                </span>
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1 rounded-md bg-slate-100 p-1">
              {SCATTER_FACTORS.map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setSelectedFactor(f.key)}
                  className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    selectedFactor === f.key
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {f.label.replace('Weekly ', '').replace('Lecture ', '').replace('Daily ', '').replace('Nightly ', '')}
                </button>
              ))}
            </div>
          </div>

          <div className="relative mt-4">
            <svg
              viewBox={`0 0 ${svgW} ${svgH}`}
              className="w-full h-auto overflow-visible"
              role="img"
              aria-label={`Scatter plot of ${factorConfig.label} versus Final Exam Score`}
            >
              {/* Y gridlines */}
              {[40, 55, 70, 85, 100].map((tick) => {
                const y = toY(tick);
                return (
                  <g key={tick}>
                    <line x1={padL} y1={y} x2={svgW - padR} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
                    <text x={padL - 8} y={y + 4} textAnchor="end" className="fill-slate-400 text-[10px] font-mono">
                      {tick}%
                    </text>
                  </g>
                );
              })}

              {/* X gridlines */}
              {Array.from({ length: 5 }, (_, idx) => {
                const val = xMin + ((xMax - xMin) * idx) / 4;
                const x = toX(val);
                return (
                  <g key={idx}>
                    <line x1={x} y1={padT} x2={x} y2={svgH - padB} stroke="#f1f5f9" />
                    <text x={x} y={svgH - padB + 16} textAnchor="middle" className="fill-slate-400 text-[10px] font-mono">
                      {Math.round(val * 10) / 10}
                    </text>
                  </g>
                );
              })}

              {/* Axis labels */}
              <text
                x={padL + plotW / 2}
                y={svgH - 4}
                textAnchor="middle"
                className="fill-slate-500 text-[11px] font-medium"
              >
                {factorConfig.label} ({factorConfig.unit})
              </text>

              {/* OLS Regression Line */}
              <line
                x1={toX(lineX1)}
                y1={toY(lineY1)}
                x2={toX(lineX2)}
                y2={toY(lineY2)}
                stroke="#1d4ed8"
                strokeWidth={2}
                strokeDasharray="6 4"
                opacity={0.75}
              />

              {/* Student Points */}
              {analytics.students.map((student) => {
                const cx = toX(Number(student[selectedFactor]));
                const cy = toY(student.avg_final_score);
                const isHovered = hoveredStudent?.student_id === student.student_id;
                const fill = DEPT_COLORS[student.dept_code] ?? '#334155';
                return (
                  <circle
                    key={student.student_id}
                    cx={cx}
                    cy={cy}
                    r={isHovered ? 7 : 5}
                    fill={fill}
                    fillOpacity={isHovered ? 1 : 0.82}
                    stroke={isHovered ? '#0f172a' : '#ffffff'}
                    strokeWidth={isHovered ? 2 : 1.2}
                    className="cursor-pointer transition-transform duration-150"
                    onMouseEnter={() => setHoveredStudent(student)}
                    onMouseLeave={() => setHoveredStudent(null)}
                    onClick={() => onSimulateStudent(student.student_id)}
                  />
                );
              })}
            </svg>

            {/* Legend & Hovered Inspector Line */}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 text-xs">
              <div className="flex flex-wrap items-center gap-4 text-slate-600">
                {Object.entries(DEPT_COLORS).map(([code, color]) => (
                  <span key={code} className="inline-flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-xs" style={{ backgroundColor: color }} />
                    {code}
                  </span>
                ))}
              </div>
              <div className="text-slate-600 tabular-nums">
                {hoveredStudent ? (
                  <span>
                    <strong className="font-medium text-slate-900">{hoveredStudent.full_name}</strong> ({hoveredStudent.roll_no}) ·{' '}
                    {factorConfig.label}: {hoveredStudent[selectedFactor]} {factorConfig.unit} · Score:{' '}
                    <strong className="font-medium text-slate-900">{hoveredStudent.avg_final_score}%</strong>
                  </span>
                ) : (
                  <span className="text-slate-400">Hover a data point to inspect or click to simulate</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Correlation Matrix Ranking */}
        <div className="xl:col-span-5 rounded-lg border border-slate-200 bg-white p-5 flex flex-col justify-between">
          <div>
            <div className="border-b border-slate-100 pb-4">
              <h2 className="text-base font-semibold text-slate-900">
                Study Factor Correlation Ranking
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Pearson correlation coefficient (r) against average final exam score
              </p>
            </div>

            <div className="mt-4 space-y-4">
              {analytics.correlations.map((item) => {
                const absWidth = Math.min(100, Math.round(Math.abs(item.pearsonR) * 100));
                const isNeg = item.pearsonR < 0;
                return (
                  <div key={item.factorKey} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-800">{item.label}</span>
                      <div className="flex items-center gap-3 tabular-nums">
                        <span className="text-slate-400">
                          mean {item.meanValue} {item.unit}
                        </span>
                        <span
                          className={`font-mono font-semibold ${
                            isNeg ? 'text-red-600' : 'text-blue-700'
                          }`}
                        >
                          {item.pearsonR >= 0 ? `+${item.pearsonR.toFixed(3)}` : item.pearsonR.toFixed(3)}
                        </span>
                      </div>
                    </div>
                    <div className="h-2 w-full rounded-sm bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full rounded-sm ${isNeg ? 'bg-red-500' : 'bg-blue-600'}`}
                        style={{ width: `${absWidth}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Study Mode Summary Table */}
          <div className="mt-6 border-t border-slate-100 pt-4">
            <h3 className="text-xs font-semibold text-slate-700 mb-2.5">
              SQL View: v_factor_impact_by_mode
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-1.5 font-medium">Mode</th>
                    <th className="py-1.5 text-right font-medium">Students</th>
                    <th className="py-1.5 text-right font-medium">Study hrs</th>
                    <th className="py-1.5 text-right font-medium">Mean Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 tabular-nums">
                  {analytics.modeSummary.map((m) => (
                    <tr key={m.preferred_mode}>
                      <td className="py-2 font-medium text-slate-800">{m.preferred_mode}</td>
                      <td className="py-2 text-right text-slate-600 font-mono">{m.student_count}</td>
                      <td className="py-2 text-right text-slate-600 font-mono">{m.mean_study_hours}</td>
                      <td className="py-2 text-right font-semibold text-slate-900 font-mono">
                        {m.mean_final_score}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Department Breakdown & Grade Distribution */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7 rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-base font-semibold text-slate-900">Department Performance Aggregate</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Joined across departments, students, study_habits, and enrollments
          </p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 font-medium">Department</th>
                  <th className="py-2 text-right font-medium">Students</th>
                  <th className="py-2 text-right font-medium">Mean Study</th>
                  <th className="py-2 text-right font-medium">Attendance</th>
                  <th className="py-2 text-right font-medium">Mean Score</th>
                  <th className="py-2 text-right font-medium">At Risk</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 tabular-nums">
                {analytics.departmentSummary.map((d) => (
                  <tr key={d.dept_code} className="hover:bg-slate-50">
                    <td className="py-2.5">
                      <span className="font-mono font-semibold text-slate-900">{d.dept_code}</span>
                      <span className="mx-1.5 text-slate-300">/</span>
                      <span className="text-slate-700">{d.dept_name}</span>
                    </td>
                    <td className="py-2.5 text-right font-mono text-slate-600">{d.student_count}</td>
                    <td className="py-2.5 text-right font-mono text-slate-600">{d.mean_study_hours} hrs</td>
                    <td className="py-2.5 text-right font-mono text-slate-600">{d.mean_attendance_pct}%</td>
                    <td className="py-2.5 text-right font-mono font-semibold text-slate-900">
                      {d.mean_final_score}%
                    </td>
                    <td className="py-2.5 text-right font-mono text-red-600">{d.at_risk_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-base font-semibold text-slate-900">Score Band Distribution</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Distribution of student mean final scores in active cohort
          </p>
          <div className="mt-4 space-y-3">
            {analytics.gradeDistribution.map((band) => {
              const pct = Math.round((band.count / maxBandCount) * 100);
              return (
                <div key={band.band} className="grid grid-cols-12 items-center gap-3 text-xs">
                  <span className="col-span-4 font-medium text-slate-700 truncate">{band.band}</span>
                  <div className="col-span-6 h-5 rounded-sm bg-slate-100 overflow-hidden">
                    <div
                      className={`h-full rounded-sm ${
                        band.band.includes('At Risk') ? 'bg-red-500' : 'bg-slate-800'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="col-span-2 text-right font-mono font-medium text-slate-700 tabular-nums">
                    {band.count}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Student Performance Directory */}
      <div className="rounded-lg border border-slate-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Student Performance & Study Factors Directory
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Backed by SQL view <span className="font-mono text-slate-700">v_student_performance_summary</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 rounded-md bg-slate-100 p-1">
              {(['ALL', 'At Risk', 'Watch', 'Nominal'] as const).map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => setRiskFilter(status)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                    riskFilter === status ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {status === 'ALL' ? 'All Status' : status}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search roll no or name..."
                className="h-8 w-52 rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>
          </div>
        </div>

        {filteredStudents.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No student records match the current search or filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500">
                  <th className="px-4 py-2.5 font-medium">Roll No</th>
                  <th className="px-4 py-2.5 font-medium">Student Name</th>
                  <th className="px-4 py-2.5 font-medium">Dept / Sem</th>
                  <th className="px-4 py-2.5 font-medium">Mode</th>
                  <th className="px-4 py-2.5 text-right font-medium">
                    <button
                      type="button"
                      onClick={() => handleSort('weekly_study_hours')}
                      className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap"
                    >
                      Study hrs <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="px-4 py-2.5 text-right font-medium">
                    <button
                      type="button"
                      onClick={() => handleSort('attendance_pct')}
                      className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap"
                    >
                      Attendance <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="px-4 py-2.5 text-right font-medium">Sleep</th>
                  <th className="px-4 py-2.5 text-right font-medium">
                    <button
                      type="button"
                      onClick={() => handleSort('distraction_hours_daily')}
                      className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap"
                    >
                      Distraction <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="px-4 py-2.5 text-right font-medium">
                    <button
                      type="button"
                      onClick={() => handleSort('avg_final_score')}
                      className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap"
                    >
                      Final Score <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="px-4 py-2.5 font-medium">Standing</th>
                  <th className="px-4 py-2.5 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 tabular-nums">
                {filteredStudents.map((s) => (
                  <tr key={s.student_id} className="hover:bg-slate-50/90 transition-colors">
                    <td className="px-4 py-2.5 font-mono text-slate-600">{s.roll_no}</td>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{s.full_name}</td>
                    <td className="px-4 py-2.5 text-slate-600">
                      {s.dept_code} <span className="text-slate-300">·</span> Sem {s.semester}
                    </td>
                    <td className="px-4 py-2.5 text-slate-600">{s.preferred_mode}</td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-700">
                      {s.weekly_study_hours.toFixed(1)}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-700">
                      {s.attendance_pct.toFixed(1)}%
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-700">
                      {s.sleep_hours_avg.toFixed(1)}h
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-slate-700">
                      {s.distraction_hours_daily.toFixed(1)}h
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono font-semibold text-slate-900">
                      {s.avg_final_score.toFixed(1)}%
                    </td>
                    <td className="px-4 py-2.5 font-medium">
                      <span
                        className={
                          s.risk_status === 'At Risk'
                            ? 'text-red-600'
                            : s.risk_status === 'Watch'
                            ? 'text-amber-600'
                            : 'text-emerald-700'
                        }
                      >
                        {s.risk_status}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <button
                        type="button"
                        onClick={() => onSimulateStudent(s.student_id)}
                        className="text-xs font-medium text-blue-700 hover:text-blue-900 hover:underline whitespace-nowrap"
                      >
                        Simulate
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
