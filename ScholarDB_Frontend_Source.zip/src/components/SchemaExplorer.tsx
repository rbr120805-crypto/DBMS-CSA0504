import { useState } from 'react';
import { KeyRound, Link2, Table2 } from 'lucide-react';
import type { SchemaMetadataPayload, TableSchemaMeta } from '../types/dbms';

interface SchemaExplorerProps {
  schema: SchemaMetadataPayload | null;
  loading: boolean;
  onOpenTable: (tableName: string) => void;
}

const ER_POSITIONS: Record<string, { x: number; y: number }> = {
  departments: { x: 40, y: 150 },
  students: { x: 320, y: 40 },
  courses: { x: 320, y: 270 },
  study_habits: { x: 630, y: 20 },
  enrollments: { x: 630, y: 175 },
  study_logs: { x: 630, y: 330 },
};

const ER_EDGES: Array<{ from: string; to: string; label: string }> = [
  { from: 'departments', to: 'students', label: '1 : N' },
  { from: 'departments', to: 'courses', label: '1 : N' },
  { from: 'students', to: 'study_habits', label: '1 : 1' },
  { from: 'students', to: 'enrollments', label: '1 : N' },
  { from: 'courses', to: 'enrollments', label: '1 : N' },
  { from: 'students', to: 'study_logs', label: '1 : N' },
  { from: 'courses', to: 'study_logs', label: '1 : N' },
];

export function SchemaExplorer({ schema, loading, onOpenTable }: SchemaExplorerProps) {
  const [selectedName, setSelectedName] = useState<string>('students');
  const [activeTab, setActiveTab] = useState<'er' | 'normalization' | 'triggers'>('er');

  if (loading && !schema) {
    return <div className="h-96 rounded-lg border border-slate-200 bg-white animate-pulse" />;
  }

  if (!schema) {
    return (
      <div className="rounded-lg border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
        Schema metadata unavailable.
      </div>
    );
  }

  const baseTables = schema.tables.filter((t) => t.kind === 'table');
  const selectedRelation: TableSchemaMeta =
    schema.tables.find((t) => t.name === selectedName) ?? schema.tables[0];

  return (
    <div className="space-y-6">
      {/* Sub-navigation bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-slate-200 bg-white px-4 py-3">
        <div className="flex items-center gap-1 rounded-md bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setActiveTab('er')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'er' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Interactive ER Diagram & DDL
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('normalization')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'normalization'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Normalization (1NF → 3NF)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('triggers')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'triggers' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Triggers & SQL Views
          </button>
        </div>

        <div className="text-xs text-slate-500 tabular-nums">
          {baseTables.length} Base Tables · {schema.views.length} Views · {schema.triggers.length} Triggers
        </div>
      </div>

      {activeTab === 'er' && (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
          {/* Interactive ER Canvas */}
          <div className="xl:col-span-7 rounded-lg border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-base font-semibold text-slate-900">
                  Entity-Relationship Topology (3NF)
                </h2>
                <p className="mt-0.5 text-xs text-slate-500">
                  Click any relation node to inspect attributes, foreign keys, and CREATE TABLE DDL
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">PRAGMA foreign_keys = ON</span>
            </div>

            <div className="mt-4 overflow-x-auto">
              <div className="relative min-w-[820px] h-[470px] rounded-md border border-slate-200 bg-slate-50/70">
                <svg className="absolute inset-0 h-full w-full pointer-events-none">
                  {ER_EDGES.map((edge) => {
                    const p1 = ER_POSITIONS[edge.from];
                    const p2 = ER_POSITIONS[edge.to];
                    if (!p1 || !p2) return null;
                    const x1 = p1.x + 185;
                    const y1 = p1.y + 44;
                    const x2 = p2.x;
                    const y2 = p2.y + 44;
                    const midX = (x1 + x2) / 2;
                    const isHighlighted = selectedName === edge.from || selectedName === edge.to;
                    return (
                      <g key={`${edge.from}-${edge.to}`}>
                        <path
                          d={`M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`}
                          fill="none"
                          stroke={isHighlighted ? '#1d4ed8' : '#cbd5e1'}
                          strokeWidth={isHighlighted ? 2 : 1.5}
                        />
                        <rect
                          x={midX - 18}
                          y={(y1 + y2) / 2 - 9}
                          width={36}
                          height={18}
                          rx={4}
                          fill="#ffffff"
                          stroke={isHighlighted ? '#1d4ed8' : '#cbd5e1'}
                        />
                        <text
                          x={midX}
                          y={(y1 + y2) / 2 + 4}
                          textAnchor="middle"
                          className={`text-[10px] font-mono ${
                            isHighlighted ? 'fill-blue-700 font-semibold' : 'fill-slate-500'
                          }`}
                        >
                          {edge.label}
                        </text>
                      </g>
                    );
                  })}
                </svg>

                {baseTables
                  .filter((t) => ER_POSITIONS[t.name])
                  .map((tbl) => {
                    const pos = ER_POSITIONS[tbl.name];
                    const isSelected = selectedName === tbl.name;
                    return (
                      <button
                        key={tbl.name}
                        type="button"
                        onClick={() => setSelectedName(tbl.name)}
                        style={{ left: pos.x, top: pos.y }}
                        className={`absolute w-[185px] rounded-md border text-left transition-colors ${
                          isSelected
                            ? 'border-blue-600 bg-white ring-2 ring-blue-100'
                            : 'border-slate-300 bg-white hover:border-slate-400'
                        }`}
                      >
                        <div
                          className={`flex items-center justify-between px-3 py-2 border-b text-xs font-semibold ${
                            isSelected
                              ? 'border-blue-100 bg-blue-50/70 text-blue-900'
                              : 'border-slate-100 bg-slate-50 text-slate-800'
                          }`}
                        >
                          <span className="font-mono truncate">{tbl.name}</span>
                          <span className="font-mono text-[11px] font-normal text-slate-500 tabular-nums">
                            {tbl.rowCount}
                          </span>
                        </div>
                        <div className="px-3 py-2 space-y-1">
                          {tbl.columns.slice(0, 4).map((col) => {
                            const isFk = tbl.foreignKeys.some((fk) => fk.from === col.name);
                            return (
                              <div key={col.name} className="flex items-center justify-between text-[11px]">
                                <span className="inline-flex items-center gap-1 font-mono text-slate-700 truncate">
                                  {col.pk === 1 && <KeyRound className="h-2.5 w-2.5 text-amber-600 shrink-0" />}
                                  {isFk && <Link2 className="h-2.5 w-2.5 text-blue-600 shrink-0" />}
                                  {col.name}
                                </span>
                                <span className="font-mono text-[10px] text-slate-400">{col.type}</span>
                              </div>
                            );
                          })}
                          {tbl.columns.length > 4 && (
                            <div className="text-[10px] text-slate-400">
                              + {tbl.columns.length - 4} more attributes
                            </div>
                          )}
                        </div>
                      </button>
                    );
                  })}
              </div>
            </div>

            {/* Quick relation selector for Views too */}
            <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
              <span className="text-xs text-slate-500 mr-1">All Schema Objects:</span>
              {schema.tables.map((t) => (
                <button
                  key={t.name}
                  type="button"
                  onClick={() => setSelectedName(t.name)}
                  className={`px-2 py-1 rounded text-xs font-mono transition-colors ${
                    selectedName === t.name
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {t.name}
                </button>
              ))}
            </div>
          </div>

          {/* Selected Relation Details */}
          <div className="xl:col-span-5 rounded-lg border border-slate-200 bg-white p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="uppercase tracking-wide font-medium">{selectedRelation.kind}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{selectedRelation.rowCount} rows</span>
                  </div>
                  <h3 className="mt-1 font-mono text-lg font-semibold text-slate-900">
                    {selectedRelation.name}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => onOpenTable(selectedRelation.name)}
                  className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0"
                >
                  <Table2 className="h-3.5 w-3.5" />
                  Browse Rows
                </button>
              </div>

              <p className="mt-3 text-xs leading-relaxed text-slate-600">
                {selectedRelation.description}
              </p>
              <p className="mt-1.5 text-xs text-slate-500">
                <strong className="font-medium text-slate-700">Normal Form:</strong> {selectedRelation.normalForm}
              </p>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-1.5 font-medium">Column</th>
                      <th className="py-1.5 font-medium">Type</th>
                      <th className="py-1.5 font-medium">Key / Constraints</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedRelation.columns.map((col) => {
                      const fk = selectedRelation.foreignKeys.find((f) => f.from === col.name);
                      const notes: string[] = [];
                      if (col.pk === 1) notes.push('PK');
                      if (fk) notes.push(`FK → ${fk.table}(${fk.to}) ON DELETE ${fk.on_delete}`);
                      if (col.notnull === 1 && col.pk === 0) notes.push('NOT NULL');
                      if (col.dflt_value !== null) notes.push(`DEFAULT ${col.dflt_value}`);
                      return (
                        <tr key={col.name}>
                          <td className="py-2 font-mono font-medium text-slate-900">{col.name}</td>
                          <td className="py-2 font-mono text-slate-500">{col.type || 'NUMERIC'}</td>
                          <td className="py-2 text-slate-600">{notes.join(' · ') || 'Nullable'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-5 border-t border-slate-100 pt-4">
              <h4 className="text-xs font-semibold text-slate-700 mb-2">SQLite DDL Definition</h4>
              <pre className="max-h-48 overflow-auto rounded-md bg-slate-900 p-3 font-mono text-[11px] leading-relaxed text-slate-100">
                {selectedRelation.sql}
              </pre>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'normalization' && (
        <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-200">
          <div className="p-5">
            <h2 className="text-base font-semibold text-slate-900">
              Relational Schema Normalization (UNF → 1NF → 2NF → 3NF / BCNF)
            </h2>
            <p className="mt-1 text-xs text-slate-600 max-w-3xl leading-relaxed">
              Academic records originally contain repeating course grades, study logs, and redundant department strings.
              Decomposing into 6 normalized relations eliminates insertion, update, and deletion anomalies while enforcing
              domain bounds with SQL CHECK and FOREIGN KEY constraints.
            </p>
          </div>
          {schema.normalizationNotes.map((note) => (
            <div key={note.stage} className="grid grid-cols-1 gap-4 p-5 md:grid-cols-12">
              <div className="md:col-span-3">
                <span className="font-mono text-sm font-semibold text-blue-700">{note.stage}</span>
                <p className="mt-1 text-xs font-medium text-slate-800">{note.title}</p>
              </div>
              <div className="md:col-span-9 space-y-2">
                <p className="text-xs leading-relaxed text-slate-600">{note.summary}</p>
                <pre className="rounded-md border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-[11px] text-slate-800 overflow-x-auto">
                  {note.example}
                </pre>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'triggers' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Automated Database Triggers</h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Automatically derive grade letters whenever final_score is inserted or updated
              </p>
            </div>
            {schema.triggers.map((trg) => (
              <div key={trg.name} className="space-y-1.5 border-t border-slate-100 pt-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono font-semibold text-slate-900">{trg.name}</span>
                  <span className="text-slate-500">on {trg.tbl_name}</span>
                </div>
                <pre className="overflow-x-auto rounded-md bg-slate-900 p-3 font-mono text-[11px] leading-relaxed text-slate-100">
                  {trg.sql}
                </pre>
              </div>
            ))}
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Materialized Analytical Views</h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Pre-joined relational queries powering the performance dashboard
              </p>
            </div>
            {schema.views.map((view) => (
              <div key={view.name} className="space-y-1.5 border-t border-slate-100 pt-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-semibold text-slate-900">{view.name}</span>
                  <button
                    type="button"
                    onClick={() => onOpenTable(view.name)}
                    className="text-xs font-medium text-blue-700 hover:underline"
                  >
                    Open View
                  </button>
                </div>
                <pre className="max-h-48 overflow-auto rounded-md bg-slate-900 p-3 font-mono text-[11px] leading-relaxed text-slate-100">
                  {view.sql}
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
