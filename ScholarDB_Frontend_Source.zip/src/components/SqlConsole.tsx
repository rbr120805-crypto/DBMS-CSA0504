import { useState } from 'react';
import { Download, Play, RotateCcw } from 'lucide-react';
import type { SqlExecutionResult } from '../types/dbms';

interface SqlConsoleProps {
  onMutated: () => void;
}

const PRESET_QUERIES: Array<{ label: string; category: string; sql: string }> = [
  {
    label: 'Top Performers & Habits (JOIN)',
    category: 'DQL',
    sql: `SELECT
  s.roll_no,
  s.full_name,
  d.dept_code,
  sh.weekly_study_hours,
  sh.attendance_pct,
  sh.distraction_hours_daily,
  ROUND(AVG(e.final_score), 1) AS mean_final_score
FROM students s
JOIN departments d ON d.dept_id = s.dept_id
JOIN study_habits sh ON sh.student_id = s.student_id
JOIN enrollments e ON e.student_id = s.student_id
GROUP BY s.student_id
ORDER BY mean_final_score DESC
LIMIT 12;`,
  },
  {
    label: 'Department Ranking (Window Fn)',
    category: 'Window',
    sql: `SELECT
  dept_code,
  roll_no,
  full_name,
  avg_final_score,
  weekly_study_hours,
  RANK() OVER (PARTITION BY dept_code ORDER BY avg_final_score DESC) AS dept_rank
FROM v_student_performance_summary
ORDER BY dept_code, dept_rank
LIMIT 20;`,
  },
  {
    label: 'At-Risk Early Warning View',
    category: 'View',
    sql: `SELECT *
FROM v_at_risk_students
ORDER BY avg_final_score ASC;`,
  },
  {
    label: 'Study Mode Impact Summary',
    category: 'Aggregate',
    sql: `SELECT * FROM v_factor_impact_by_mode;`,
  },
  {
    label: 'Deep Work Logs per Course',
    category: 'Grouping',
    sql: `SELECT
  c.course_code,
  c.course_title,
  COUNT(sl.log_id) AS session_count,
  SUM(sl.duration_minutes) AS total_minutes,
  ROUND(AVG(sl.focus_rating), 2) AS avg_focus_rating
FROM courses c
JOIN study_logs sl ON sl.course_id = c.course_id
GROUP BY c.course_id
ORDER BY total_minutes DESC;`,
  },
  {
    label: 'Test CHECK Constraint Violation',
    category: 'ACID Test',
    sql: `-- Demonstrates real SQLite CHECK(attendance_pct BETWEEN 0 AND 100) enforcement
INSERT INTO study_habits (
  student_id, weekly_study_hours, sleep_hours_avg,
  attendance_pct, preferred_mode, distraction_hours_daily, internet_access_quality
) VALUES (1, 20, 7.5, 145.0, 'Solo', 1.5, 'High');`,
  },
];

export function SqlConsole({ onMutated }: SqlConsoleProps) {
  const [sql, setSql] = useState<string>(PRESET_QUERIES[0].sql);
  const [result, setResult] = useState<SqlExecutionResult | null>(null);
  const [running, setRunning] = useState(false);

  const runQuery = async (queryToRun?: string) => {
    const activeSql = queryToRun ?? sql;
    setRunning(true);
    try {
      const res = await fetch('/api/sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: activeSql }),
      });
      const data = (await res.json()) as SqlExecutionResult;
      setResult(data);
      if (data.success && (data.statementType === 'DML' || data.statementType === 'DDL')) {
        onMutated();
      }
    } catch (err) {
      setResult({
        success: false,
        columns: [],
        rows: [],
        rowCount: 0,
        changes: 0,
        executionMs: 0,
        statementType: 'ERROR',
        error: err instanceof Error ? err.message : 'Network error running SQL query',
      });
    } finally {
      setRunning(false);
    }
  };

  const exportCsv = () => {
    if (!result || !result.success || result.rows.length === 0) return;
    const header = result.columns.join(',');
    const lines = result.rows.map((row) =>
      result.columns
        .map((col) => {
          const val = row[col] ?? '';
          const str = String(val).replace(/"/g, '""');
          return `"${str}"`;
        })
        .join(',')
    );
    const csv = [header, ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'scholardb_query_result.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Preset Queries List */}
        <div className="lg:col-span-4 rounded-lg border border-slate-200 bg-white p-4">
          <h2 className="text-sm font-semibold text-slate-900">Saved DBMS Queries</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Load relational joins, window functions, views, or constraint tests
          </p>
          <div className="mt-3 divide-y divide-slate-100">
            {PRESET_QUERIES.map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => {
                  setSql(preset.sql);
                  void runQuery(preset.sql);
                }}
                className="w-full py-2.5 text-left hover:bg-slate-50 px-2 rounded transition-colors flex items-center justify-between gap-2"
              >
                <span className="text-xs font-medium text-slate-800 truncate">{preset.label}</span>
                <span className="font-mono text-[11px] text-slate-400 shrink-0">{preset.category}</span>
              </button>
            ))}
          </div>
        </div>

        {/* SQL Editor */}
        <div className="lg:col-span-8 rounded-lg border border-slate-200 bg-white p-4 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">SQLite Query Editor</h2>
                <p className="text-xs text-slate-500">
                  Supports SELECT, WITH, JOIN, Window Functions, INSERT, UPDATE, DELETE, and DDL
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSql(PRESET_QUERIES[0].sql)}
                  className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Reset Query
                </button>
                <button
                  type="button"
                  disabled={running}
                  onClick={() => void runQuery()}
                  className="inline-flex items-center gap-1.5 rounded-md bg-blue-700 px-4 py-1.5 text-xs font-medium text-white hover:bg-blue-800 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <Play className="h-3.5 w-3.5" />
                  {running ? 'Running...' : 'Execute SQL'}
                </button>
              </div>
            </div>

            <textarea
              value={sql}
              onChange={(e) => setSql(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                  e.preventDefault();
                  void runQuery();
                }
              }}
              spellCheck={false}
              rows={10}
              className="mt-3 w-full rounded-md border border-slate-200 bg-slate-950 p-3.5 font-mono text-xs leading-relaxed text-slate-100 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Press Ctrl/Cmd + Enter to execute</span>
            <span>Engine: SQLite 3 (WASM) · Foreign Keys Enforced</span>
          </div>
        </div>
      </div>

      {/* Results Output */}
      <div className="rounded-lg border border-slate-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-3">
          <div className="flex items-center gap-3 text-xs">
            <span className="font-semibold text-slate-900">Query Output</span>
            {result && (
              <>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className={result.success ? 'text-emerald-700 font-medium' : 'text-red-600 font-medium'}>
                  {result.success ? `${result.statementType} succeeded` : 'Constraint / Syntax Error'}
                </span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="font-mono text-slate-500 tabular-nums">
                  {result.rowCount} rows in {result.executionMs} ms
                </span>
              </>
            )}
          </div>

          {result?.success && result.rows.length > 0 && (
            <button
              type="button"
              onClick={exportCsv}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Export CSV
            </button>
          )}
        </div>

        {!result ? (
          <div className="p-8 text-center text-xs text-slate-500">
            Execute a SQL statement or select a preset query above to inspect results.
          </div>
        ) : !result.success ? (
          <div className="p-5">
            <div className="rounded-md border border-red-200 bg-red-50 p-4 font-mono text-xs text-red-800">
              {result.error}
            </div>
          </div>
        ) : result.rows.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            Query executed successfully and returned 0 rows.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                  {result.columns.map((col) => (
                    <th key={col} className="px-4 py-2.5 font-mono font-semibold whitespace-nowrap">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 tabular-nums">
                {result.rows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    {result.columns.map((col) => {
                      const val = row[col];
                      const isNumeric = typeof val === 'number';
                      return (
                        <td
                          key={col}
                          className={`px-4 py-2 whitespace-nowrap ${
                            isNumeric ? 'font-mono text-slate-800' : 'text-slate-700'
                          }`}
                        >
                          {val === null || val === undefined ? (
                            <span className="font-mono text-slate-400">NULL</span>
                          ) : (
                            String(val)
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
