export type NavSection =
  | 'dashboard'
  | 'schema'
  | 'console'
  | 'tables'
  | 'simulator';

export interface Department {
  dept_id: number;
  dept_code: string;
  dept_name: string;
  faculty_lead: string;
  building: string;
}

export interface StudentPerformanceRow {
  student_id: number;
  roll_no: string;
  full_name: string;
  email: string;
  dept_id: number;
  dept_code: string;
  dept_name: string;
  enrollment_year: number;
  semester: number;
  prior_gpa: number;
  extracurricular_hours: number;
  commute_minutes: number;
  weekly_study_hours: number;
  sleep_hours_avg: number;
  attendance_pct: number;
  preferred_mode: 'Solo' | 'Study Group' | 'Hybrid';
  distraction_hours_daily: number;
  tutoring_sessions_month: number;
  internet_access_quality: 'High' | 'Moderate' | 'Limited';
  courses_enrolled: number;
  avg_midterm_score: number;
  avg_assignment_score: number;
  avg_final_score: number;
  total_practice_tests: number;
  logged_study_minutes: number;
  avg_focus_rating: number;
  risk_status: 'Nominal' | 'Watch' | 'At Risk';
}

export interface FactorCorrelation {
  factorKey: string;
  label: string;
  unit: string;
  pearsonR: number;
  direction: 'positive' | 'negative';
  meanValue: number;
}

export interface ModeSummary {
  preferred_mode: string;
  student_count: number;
  mean_final_score: number;
  mean_study_hours: number;
  mean_attendance_pct: number;
  mean_sleep_hours: number;
}

export interface DepartmentSummary {
  dept_code: string;
  dept_name: string;
  student_count: number;
  mean_final_score: number;
  mean_study_hours: number;
  mean_attendance_pct: number;
  at_risk_count: number;
}

export interface GradeDistributionItem {
  band: string;
  count: number;
}

export interface RegressionModel {
  intercept: number;
  rSquared: number;
  rmse: number;
  weights: {
    weekly_study_hours: number;
    attendance_pct: number;
    sleep_hours_avg: number;
    distraction_hours_daily: number;
    practice_tests_per_course: number;
    prior_gpa: number;
  };
}

export interface AnalyticsPayload {
  students: StudentPerformanceRow[];
  departments: Department[];
  correlations: FactorCorrelation[];
  modeSummary: ModeSummary[];
  departmentSummary: DepartmentSummary[];
  gradeDistribution: GradeDistributionItem[];
  regressionModel: RegressionModel;
  kpis: {
    totalStudents: number;
    totalEnrollments: number;
    totalStudyLogs: number;
    meanFinalScore: number;
    meanStudyHours: number;
    meanAttendance: number;
    atRiskCount: number;
  };
}

export interface ColumnMeta {
  cid: number;
  name: string;
  type: string;
  notnull: number;
  dflt_value: string | null;
  pk: number;
}

export interface ForeignKeyMeta {
  id: number;
  seq: number;
  table: string;
  from: string;
  to: string;
  on_update: string;
  on_delete: string;
}

export interface TableSchemaMeta {
  name: string;
  kind: 'table' | 'view';
  rowCount: number;
  sql: string;
  columns: ColumnMeta[];
  foreignKeys: ForeignKeyMeta[];
  indexes: string[];
  description: string;
  normalForm: string;
}

export interface SchemaMetadataPayload {
  tables: TableSchemaMeta[];
  triggers: Array<{ name: string; tbl_name: string; sql: string }>;
  views: Array<{ name: string; sql: string }>;
  normalizationNotes: Array<{
    stage: string;
    title: string;
    summary: string;
    example: string;
  }>;
}

export interface SqlExecutionResult {
  success: boolean;
  columns: string[];
  rows: Array<Record<string, unknown>>;
  rowCount: number;
  changes: number;
  executionMs: number;
  statementType: 'SELECT' | 'DML' | 'DDL' | 'PRAGMA' | 'ERROR';
  error?: string;
}

export interface TableRowsPayload {
  tableName: string;
  kind: 'table' | 'view';
  columns: ColumnMeta[];
  foreignKeys: ForeignKeyMeta[];
  rows: Array<Record<string, unknown>>;
  totalCount: number;
  lookupOptions: Record<string, Array<{ value: string | number; label: string }>>;
}
