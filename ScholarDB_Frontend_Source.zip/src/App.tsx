import { useCallback, useEffect, useState } from 'react';
import {
  BarChart3,
  Database,
  Download,
  FileText,
  Menu,
  Network,
  Plus,
  RefreshCw,
  Sliders,
  Table2,
  TerminalSquare,
  X,
} from 'lucide-react';
import { AddStudentModal } from './components/AddStudentModal';
import { FactorSimulator } from './components/FactorSimulator';
import { PerformanceDashboard } from './components/PerformanceDashboard';
import { SchemaExplorer } from './components/SchemaExplorer';
import { SqlConsole } from './components/SqlConsole';
import { TableBrowser } from './components/TableBrowser';
import type { AnalyticsPayload, NavSection, SchemaMetadataPayload } from './types/dbms';

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  breadcrumb: string;
  icon: typeof BarChart3;
}> = [
  {
    id: 'dashboard',
    label: 'Performance Dashboard',
    breadcrumb: 'Performance & Study Factors',
    icon: BarChart3,
  },
  {
    id: 'schema',
    label: 'ER Schema & Normalization',
    breadcrumb: 'Relational Schema (3NF)',
    icon: Network,
  },
  {
    id: 'console',
    label: 'SQL Query Console',
    breadcrumb: 'Live SQLite Sandbox',
    icon: TerminalSquare,
  },
  {
    id: 'tables',
    label: 'Table Browser & CRUD',
    breadcrumb: 'Relation Inspector',
    icon: Table2,
  },
  {
    id: 'simulator',
    label: 'Study Factor Simulator',
    breadcrumb: 'OLS Regression Predictor',
    icon: Sliders,
  },
];

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [deptFilter, setDeptFilter] = useState<string>('ALL');
  const [modeFilter, setModeFilter] = useState<string>('ALL');

  const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);
  const [schema, setSchema] = useState<SchemaMetadataPayload | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [resetting, setResetting] = useState<boolean>(false);

  const [selectedTable, setSelectedTable] = useState<string>('students');
  const [simulatorStudentId, setSimulatorStudentId] = useState<number | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const fetchAnalytics = useCallback(async (dept = deptFilter, mode = modeFilter) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (dept !== 'ALL') params.set('dept', dept);
      if (mode !== 'ALL') params.set('mode', mode);
      const res = await fetch(`/api/analytics?${params.toString()}`);
      if (res.ok) {
        const data = (await res.json()) as AnalyticsPayload;
        setAnalytics(data);
      }
    } finally {
      setLoading(false);
    }
  }, [deptFilter, modeFilter]);

  const fetchSchema = useCallback(async () => {
    const res = await fetch('/api/schema');
    if (res.ok) {
      const data = (await res.json()) as SchemaMetadataPayload;
      setSchema(data);
    }
  }, []);

  useEffect(() => {
    void fetchAnalytics(deptFilter, modeFilter);
  }, [deptFilter, modeFilter, fetchAnalytics]);

  useEffect(() => {
    void fetchSchema();
  }, [fetchSchema]);

  const handleDatabaseMutated = () => {
    void fetchAnalytics(deptFilter, modeFilter);
    void fetchSchema();
  };

  const handleResetDb = async () => {
    setResetting(true);
    try {
      const res = await fetch('/api/reset', { method: 'POST' });
      if (res.ok) {
        setDeptFilter('ALL');
        setModeFilter('ALL');
        await Promise.all([fetchAnalytics('ALL', 'ALL'), fetchSchema()]);
      }
    } finally {
      setResetting(false);
    }
  };

  const handleOpenTable = (tableName: string) => {
    setSelectedTable(tableName);
    setActiveSection('tables');
  };

  const handleSimulateStudent = (studentId: number) => {
    setSimulatorStudentId(studentId);
    setActiveSection('simulator');
  };

  const [downloadingPart, setDownloadingPart] = useState<
    'frontend' | 'backend' | 'full' | 'pdf' | null
  >(null);

  const handleDownloadCode = async (part: 'frontend' | 'backend' | 'full') => {
    setDownloadingPart(part);
    try {
      const res = await fetch(`/api/download-zip/${part}`);
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download =
        part === 'frontend'
          ? 'ScholarDB_Frontend_Source.zip'
          : part === 'backend'
          ? 'ScholarDB_Backend_Source.zip'
          : 'ScholarDB_Full_Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } finally {
      setDownloadingPart(null);
    }
  };

  const handleDownloadPdf = async () => {
    setDownloadingPart('pdf');
    try {
      const res = await fetch('/api/download-pdf');
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'ScholarDB_DBMS_Project_Report.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } finally {
      setDownloadingPart(null);
    }
  };

  const currentNav = NAV_ITEMS.find((item) => item.id === activeSection) ?? NAV_ITEMS[0];
  const baseTableCount = schema?.tables.filter((t) => t.kind === 'table').length ?? 6;
  const viewCount = schema?.views.length ?? 3;
  const triggerCount = schema?.triggers.length ?? 2;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white">
        <div className="flex h-14 items-center gap-2.5 border-b border-slate-200 px-5">
          <Database className="h-4 w-4 text-blue-700 shrink-0" />
          <span className="font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
            ScholarDB
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-4">
          <p className="px-3 mb-2 text-[11px] font-semibold text-slate-400">
            Workspace Modules
          </p>
          <nav className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center gap-2.5 rounded-md px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="mt-8 border-t border-slate-100 pt-4 px-3 space-y-2.5 text-xs">
            <p className="text-[11px] font-semibold text-slate-400">Relational Catalog</p>
            <div className="flex justify-between text-slate-600 tabular-nums">
              <span>Base Tables (3NF)</span>
              <span className="font-mono font-medium text-slate-900">{baseTableCount}</span>
            </div>
            <div className="flex justify-between text-slate-600 tabular-nums">
              <span>SQL Views</span>
              <span className="font-mono font-medium text-slate-900">{viewCount}</span>
            </div>
            <div className="flex justify-between text-slate-600 tabular-nums">
              <span>Active Triggers</span>
              <span className="font-mono font-medium text-slate-900">{triggerCount}</span>
            </div>
            <div className="flex justify-between text-slate-600 tabular-nums">
              <span>Study Logs</span>
              <span className="font-mono font-medium text-slate-900">
                {analytics?.kpis.totalStudyLogs ?? 0}
              </span>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-200 p-3">
          <button
            type="button"
            disabled={resetting}
            onClick={() => void handleResetDb()}
            className="w-full inline-flex items-center justify-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${resetting ? 'animate-spin' : ''}`} />
            {resetting ? 'Resetting SQLite...' : 'Reset Seed Dataset'}
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-50 flex w-64 flex-col bg-white border-r border-slate-200">
            <div className="flex h-14 items-center justify-between border-b border-slate-200 px-4">
              <span className="font-display text-base font-bold text-slate-900">ScholarDB</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="rounded p-1 text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveSection(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 rounded-md px-3 py-2.5 text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="border-t border-slate-200 p-3">
              <button
                type="button"
                disabled={resetting}
                onClick={() => void handleResetDb()}
                className="w-full inline-flex items-center justify-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${resetting ? 'animate-spin' : ''}`} />
                Reset Seed Dataset
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Viewport */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-4 border-b border-slate-200 bg-white px-4 sm:px-6">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden rounded-md p-1.5 text-slate-600 hover:bg-slate-100"
              aria-label="Open navigation menu"
            >
              <Menu className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2 text-xs text-slate-500 truncate">
              <span className="hidden sm:inline whitespace-nowrap">Academic DBMS</span>
              <span className="hidden sm:inline text-slate-300" aria-hidden="true">/</span>
              <h1 className="font-display text-sm font-semibold text-slate-900 truncate">
                {currentNav.breadcrumb}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-1.5 rounded-md bg-blue-700 px-3.5 py-2 text-xs font-medium text-white hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Enroll Student
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-[1440px] w-full mx-auto space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 text-xs">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-slate-600">
              <span className="font-medium text-slate-500">Presented by</span>
              <span className="font-display font-semibold text-slate-900 tracking-tight">
                RICHARD BENSON RAJ.B.A
              </span>
              <span className="text-slate-300" aria-hidden="true">·</span>
              <span className="font-display font-semibold text-slate-900 tracking-tight">
                AJAY.B
              </span>
              <span className="text-slate-300" aria-hidden="true">·</span>
              <span className="font-display font-semibold text-slate-900 tracking-tight">
                S.MOHAMED ASFARALI
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                disabled={downloadingPart !== null}
                onClick={() => void handleDownloadCode('frontend')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Download className="h-3.5 w-3.5 text-blue-700" />
                {downloadingPart === 'frontend' ? 'Preparing...' : 'Frontend (.zip)'}
              </button>
              <button
                type="button"
                disabled={downloadingPart !== null}
                onClick={() => void handleDownloadCode('backend')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Download className="h-3.5 w-3.5 text-blue-700" />
                {downloadingPart === 'backend' ? 'Preparing...' : 'Backend (.zip)'}
              </button>
              <button
                type="button"
                disabled={downloadingPart !== null}
                onClick={() => void handleDownloadCode('full')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Download className="h-3.5 w-3.5 text-blue-700" />
                {downloadingPart === 'full' ? 'Preparing...' : 'Full Project (.zip)'}
              </button>
              <button
                type="button"
                disabled={downloadingPart !== null}
                onClick={() => void handleDownloadPdf()}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <FileText className="h-3.5 w-3.5" />
                {downloadingPart === 'pdf' ? 'Generating PDF...' : 'Module Report (.pdf)'}
              </button>
            </div>
          </div>

          {activeSection === 'dashboard' && (
            <PerformanceDashboard
              analytics={analytics}
              loading={loading}
              deptFilter={deptFilter}
              modeFilter={modeFilter}
              onDeptFilterChange={setDeptFilter}
              onModeFilterChange={setModeFilter}
              onSimulateStudent={handleSimulateStudent}
            />
          )}

          {activeSection === 'schema' && (
            <SchemaExplorer
              schema={schema}
              loading={loading}
              onOpenTable={handleOpenTable}
            />
          )}

          {activeSection === 'console' && (
            <SqlConsole onMutated={handleDatabaseMutated} />
          )}

          {activeSection === 'tables' && (
            <TableBrowser
              schema={schema}
              selectedTable={selectedTable}
              onSelectTable={setSelectedTable}
              onMutated={handleDatabaseMutated}
            />
          )}

          {activeSection === 'simulator' && (
            <FactorSimulator
              analytics={analytics}
              selectedStudentId={simulatorStudentId}
              onSelectStudentId={setSimulatorStudentId}
              onCommitted={handleDatabaseMutated}
            />
          )}
        </main>
      </div>

      {showAddModal && analytics && (
        <AddStudentModal
          departments={analytics.departments}
          onClose={() => setShowAddModal(false)}
          onCreated={handleDatabaseMutated}
        />
      )}
    </div>
  );
}
